/**
 * SPEC - Sistema de Controle de Ponto Eletrônico (PWA Tablet/Desktop)
 * Tipos e interfaces de dados do sistema REP-P
 */

export type TipoEventoPonto = 
  | 'ENTRADA' 
  | 'SAIDA_INTERVALO' 
  | 'RETORNO_INTERVALO' 
  | 'SAIDA_EXPEDIENTE';

export type MetodoAutenticacao = 
  | 'BIOMETRIA_FACIAL' 
  | 'PIN' 
  | 'RFID_CARTAO';

export type StatusImpressora = 
  | 'OPERACIONAL' 
  | 'SEM_PAPEL' 
  | 'DEFEITO';

export type TipoInconsistencia = 
  | 'ATRASO_ENTRADA' 
  | 'SAIDA_ANTECIPADA' 
  | 'INTERVALO_IRREGULAR' 
  | 'MARCACAO_FORA_FAIXA' 
  | 'FALTA_INJUSTIFICADA' 
  | 'JUSTIFICATIVA_PENDENTE';

export interface EmpresaConfig {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  endereco: string;
  registroMTE: string;
  numeroEquipamento: string;
}

export interface Colaborador {
  id: string;
  nome: string;
  cpf: string;
  pis: string;
  cargo: string;
  departamento: string;
  email: string;
  pin: string;
  rfidTag: string;
  turnoDescricao: string;
  jornadaPrevista: {
    entrada: string;        // ex: "08:00"
    saidaIntervalo: string; // ex: "12:00"
    retornoIntervalo: string; // ex: "13:00"
    saidaExpediente: string;  // ex: "17:48"
  };
  ativo: boolean;
  avatarUrl?: string;
}

export interface RegistroPonto {
  id: string;
  nsr: number; // Número Sequencial de Registro
  colaboradorId: string;
  colaboradorNome: string;
  pis: string;
  cpf: string;
  cargo: string;
  tipoEvento: TipoEventoPonto;
  timestampUtc: string;
  timestampLocal: string;
  dataIso: string; // YYYY-MM-DD
  horaLocal: string; // HH:mm:ss
  metodoAutenticacao: MetodoAutenticacao;
  fotoBase64?: string;
  hashSha256: string;
  sincronizado: boolean;
  comprovanteEmitido: boolean;
  modoComprovante: 'IMPRESSO' | 'DIGITAL_EMAIL' | 'AMBOS';
  emailEnviadoPara?: string;
  justificativa?: string;
  motivoJustificativa?: string;
  excedeTolerancia: boolean;
  minutosVariacao: number;
}

export interface AlertaInconsistencia {
  id: string;
  dataIso: string;
  colaboradorId: string;
  colaboradorNome: string;
  cargo: string;
  tipo: TipoInconsistencia;
  descricao: string;
  registroPontoId?: string;
  resolvido: boolean;
  observacaoRH?: string;
  dataResolucao?: string;
  criadoEm: string;
}

export interface AtestadoMedico {
  id: string;
  colaboradorId: string;
  colaboradorNome: string;
  dataEmissao: string;
  dataInicio: string;
  dataFim: string;
  diasAbono: number;
  cid: string;
  medicoCrm: string;
  medicoNome: string;
  motivo: string;
  anexoNome?: string;
  status: 'APROVADO' | 'PENDENTE' | 'REJEITADO';
  criadoEm: string;
}

export interface HardwareState {
  impressoraStatus: StatusImpressora;
  bobinaPorcentagem: number;
  redeOnline: boolean;
  cameraAtiva: boolean;
}
