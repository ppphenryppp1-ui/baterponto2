/**
 * RNF-01: Arquitetura PWA Offline-First com IndexedDB
 * Persistência local imutável, suporte a contingência sem internet
 * e sincronização transparente ao restabelecer conectividade.
 */

import {
  AlertaInconsistencia,
  AtestadoMedico,
  Colaborador,
  EmpresaConfig,
  RegistroPonto,
} from '../types';

const DB_NAME = 'REP_P_DATABASE_v1';
const DB_VERSION = 1;

const DEFAULT_EMPRESA: EmpresaConfig = {
  razaoSocial: 'TECHSOLUTIONS INDÚSTRIA & TECNOLOGIA S.A.',
  nomeFantasia: 'TechSolutions REP Eletrônico',
  cnpj: '14.285.912/0001-44',
  endereco: 'Av. Paulista, 1842 - Bela Vista, São Paulo - SP, CEP 01310-923',
  registroMTE: 'REP-P Nº 849.201-SP (Portaria MTE 671/2021)',
  numeroEquipamento: 'EQP-PWA-00148',
};

const DEFAULT_COLABORADORES: Colaborador[] = [
  {
    id: 'colab-1',
    nome: 'Carlos Eduardo Silva',
    cpf: '284.912.488-91',
    pis: '128.49201.88-3',
    cargo: 'Analista de Sistemas Sênior',
    departamento: 'Engenharia de Software',
    email: 'carlos.silva@techsolutions.com.br',
    pin: '1234',
    rfidTag: 'TAG-9941',
    turnoDescricao: '08:00 às 17:48 (Intervalo 12:00 às 13:00)',
    jornadaPrevista: {
      entrada: '08:00',
      saidaIntervalo: '12:00',
      retornoIntervalo: '13:00',
      saidaExpediente: '17:48',
    },
    ativo: true,
  },
  {
    id: 'colab-2',
    nome: 'Mariana Souza Santos',
    cpf: '319.482.711-04',
    pis: '135.88291.44-1',
    cargo: 'Engenheira de Automação',
    departamento: 'P&D Industrial',
    email: 'mariana.souza@techsolutions.com.br',
    pin: '4321',
    rfidTag: 'TAG-8823',
    turnoDescricao: '08:00 às 17:48 (Intervalo 12:00 às 13:00)',
    jornadaPrevista: {
      entrada: '08:00',
      saidaIntervalo: '12:00',
      retornoIntervalo: '13:00',
      saidaExpediente: '17:48',
    },
    ativo: true,
  },
  {
    id: 'colab-3',
    nome: 'Roberto Alves Cunha',
    cpf: '192.839.401-22',
    pis: '142.11029.33-7',
    cargo: 'Técnico de Manutenção Eletromecânica',
    departamento: 'Operações e Infraestrutura',
    email: 'roberto.cunha@techsolutions.com.br',
    pin: '7788',
    rfidTag: 'TAG-4412',
    turnoDescricao: '07:00 às 16:48 (Intervalo 11:30 às 12:30)',
    jornadaPrevista: {
      entrada: '07:00',
      saidaIntervalo: '11:30',
      retornoIntervalo: '12:30',
      saidaExpediente: '16:48',
    },
    ativo: true,
  },
  {
    id: 'colab-4',
    nome: 'Juliana Mendes Castro',
    cpf: '411.029.384-55',
    pis: '160.49182.11-9',
    cargo: 'Supervisora de RH & Qualidade',
    departamento: 'Recursos Humanos',
    email: 'juliana.mendes@techsolutions.com.br',
    pin: '9900',
    rfidTag: 'TAG-1205',
    turnoDescricao: '09:00 às 18:48 (Intervalo 13:00 às 14:00)',
    jornadaPrevista: {
      entrada: '09:00',
      saidaIntervalo: '13:00',
      retornoIntervalo: '14:00',
      saidaExpediente: '18:48',
    },
    ativo: true,
  },
  {
    id: 'colab-5',
    nome: 'Lucas Ferreira Lima',
    cpf: '502.918.234-88',
    pis: '159.20194.77-2',
    cargo: 'Operador de Produção',
    departamento: 'Linha de Montagem',
    email: 'lucas.ferreira@techsolutions.com.br',
    pin: '5566',
    rfidTag: 'TAG-3390',
    turnoDescricao: '06:00 às 15:48 (Intervalo 11:00 às 12:00)',
    jornadaPrevista: {
      entrada: '06:00',
      saidaIntervalo: '11:00',
      retornoIntervalo: '12:00',
      saidaExpediente: '15:48',
    },
    ativo: true,
  },
];

class DatabaseService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB não suportado'));
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Tabela de Configuração
        if (!db.objectStoreNames.contains('config')) {
          db.createObjectStore('config', { keyPath: 'key' });
        }

        // Tabela de Colaboradores
        if (!db.objectStoreNames.contains('colaboradores')) {
          const colabStore = db.createObjectStore('colaboradores', { keyPath: 'id' });
          colabStore.createIndex('pin', 'pin', { unique: false });
          colabStore.createIndex('rfidTag', 'rfidTag', { unique: false });
        }

        // Tabela de Registros de Ponto (Imutável)
        if (!db.objectStoreNames.contains('registros')) {
          const regStore = db.createObjectStore('registros', { keyPath: 'id' });
          regStore.createIndex('nsr', 'nsr', { unique: true });
          regStore.createIndex('colaboradorId', 'colaboradorId', { unique: false });
          regStore.createIndex('dataIso', 'dataIso', { unique: false });
          regStore.createIndex('sincronizado', 'sincronizado', { unique: false });
        }

        // Tabela de Inconsistências
        if (!db.objectStoreNames.contains('inconsistencias')) {
          const incStore = db.createObjectStore('inconsistencias', { keyPath: 'id' });
          incStore.createIndex('colaboradorId', 'colaboradorId', { unique: false });
          incStore.createIndex('resolvido', 'resolvido', { unique: false });
        }

        // Tabela de Atestados
        if (!db.objectStoreNames.contains('atestados')) {
          const atestStore = db.createObjectStore('atestados', { keyPath: 'id' });
          atestStore.createIndex('colaboradorId', 'colaboradorId', { unique: false });
        }
      };

      request.onsuccess = async () => {
        const db = request.result;
        await this.seedDefaults(db);
        resolve(db);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  private async seedDefaults(db: IDBDatabase): Promise<void> {
    // Verifica se colaboradores já existem
    const tx = db.transaction(['config', 'colaboradores', 'registros', 'atestados'], 'readwrite');
    const colabStore = tx.objectStore('colaboradores');
    const configStore = tx.objectStore('config');
    const regStore = tx.objectStore('registros');
    const atestStore = tx.objectStore('atestados');

    // Inicializa config se não existir
    const configReq = configStore.get('empresa');
    configReq.onsuccess = () => {
      if (!configReq.result) {
        configStore.put({ key: 'empresa', value: DEFAULT_EMPRESA });
      }
    };

    // Inicializa colaboradores se estiver vazio
    const countReq = colabStore.count();
    countReq.onsuccess = () => {
      if (countReq.result === 0) {
        DEFAULT_COLABORADORES.forEach((colab) => {
          colabStore.put(colab);
        });
      }
    };

    // Inicializa alguns registros padrão para o dia atual se não houver registros
    const regCountReq = regStore.count();
    regCountReq.onsuccess = () => {
      if (regCountReq.result === 0) {
        const hoje = new Date().toISOString().split('T')[0];
        const baseTimestamp = new Date();
        baseTimestamp.setHours(8, 2, 0, 0);

        // Exemplo de registro para demonstrar histórico
        const reg1: RegistroPonto = {
          id: 'reg-demo-1',
          nsr: 1045,
          colaboradorId: 'colab-1',
          colaboradorNome: 'Carlos Eduardo Silva',
          cpf: '284.912.488-91',
          pis: '128.49201.88-3',
          cargo: 'Analista de Sistemas Sênior',
          tipoEvento: 'ENTRADA',
          timestampUtc: baseTimestamp.toISOString(),
          timestampLocal: baseTimestamp.toLocaleString('pt-BR'),
          dataIso: hoje,
          horaLocal: '08:02:15',
          metodoAutenticacao: 'BIOMETRIA_FACIAL',
          hashSha256: 'B4A2F9081C65E39DA7E90B42D1589C1920AF891B45672A99E3CD9128AA41982F',
          sincronizado: true,
          comprovanteEmitido: true,
          modoComprovante: 'IMPRESSO',
          excedeTolerancia: false,
          minutosVariacao: 2,
        };
        regStore.put(reg1);
      }
    };

    // Atestado de exemplo
    const atestCountReq = atestStore.count();
    atestCountReq.onsuccess = () => {
      if (atestCountReq.result === 0) {
        const atestadoDemo: AtestadoMedico = {
          id: 'atest-demo-1',
          colaboradorId: 'colab-5',
          colaboradorNome: 'Lucas Ferreira Lima',
          dataEmissao: new Date().toISOString().split('T')[0],
          dataInicio: new Date().toISOString().split('T')[0],
          dataFim: new Date().toISOString().split('T')[0],
          diasAbono: 1,
          cid: 'J06.9 - Infecção Aguda das Vias Aéreas',
          medicoCrm: 'CRM/SP 192841',
          medicoNome: 'Dr. Fernando Paiva',
          motivo: 'Consulta médica de urgência com repouso prescrito de 1 dia.',
          anexoNome: 'atestado_medico_urgencia.pdf',
          status: 'APROVADO',
          criadoEm: new Date().toISOString(),
        };
        atestStore.put(atestadoDemo);
      }
    };
  }

  async getEmpresaConfig(): Promise<EmpresaConfig> {
    const db = await this.open();
    return new Promise((resolve) => {
      const tx = db.transaction('config', 'readonly');
      const store = tx.objectStore('config');
      const req = store.get('empresa');
      req.onsuccess = () => {
        resolve(req.result ? req.result.value : DEFAULT_EMPRESA);
      };
      req.onerror = () => resolve(DEFAULT_EMPRESA);
    });
  }

  async getColaboradores(): Promise<Colaborador[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('colaboradores', 'readonly');
      const store = tx.objectStore('colaboradores');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async getColaboradorById(id: string): Promise<Colaborador | null> {
    const db = await this.open();
    return new Promise((resolve) => {
      const tx = db.transaction('colaboradores', 'readonly');
      const store = tx.objectStore('colaboradores');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  }

  async getColaboradorByPin(pin: string): Promise<Colaborador | null> {
    const colaboradores = await this.getColaboradores();
    return colaboradores.find((c) => c.pin === pin && c.ativo) || null;
  }

  async getColaboradorByRfid(rfid: string): Promise<Colaborador | null> {
    const colaboradores = await this.getColaboradores();
    const cleanRfid = rfid.trim().toUpperCase();
    return (
      colaboradores.find(
        (c) => (c.rfidTag.toUpperCase() === cleanRfid || c.id === cleanRfid) && c.ativo
      ) || null
    );
  }

  async getProximoNsr(): Promise<number> {
    const db = await this.open();
    return new Promise((resolve) => {
      const tx = db.transaction('registros', 'readonly');
      const store = tx.objectStore('registros');
      const index = store.index('nsr');
      const req = index.openCursor(null, 'prev');
      req.onsuccess = () => {
        const cursor = req.result;
        if (cursor && cursor.value && typeof cursor.value.nsr === 'number') {
          resolve(cursor.value.nsr + 1);
        } else {
          resolve(1046);
        }
      };
      req.onerror = () => resolve(1046);
    });
  }

  async salvarRegistro(registro: RegistroPonto): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('registros', 'readwrite');
      const store = tx.objectStore('registros');
      const req = store.put(registro);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getRegistros(filtroDataIso?: string): Promise<RegistroPonto[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('registros', 'readonly');
      const store = tx.objectStore('registros');
      const req = store.getAll();
      req.onsuccess = () => {
        let lista = (req.result as RegistroPonto[]) || [];
        if (filtroDataIso) {
          lista = lista.filter((r) => r.dataIso === filtroDataIso);
        }
        // Ordena por NSR decrescente
        lista.sort((a, b) => b.nsr - a.nsr);
        resolve(lista);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getRegistrosDoColaboradorNoDia(
    colaboradorId: string,
    dataIso: string
  ): Promise<RegistroPonto[]> {
    const registros = await this.getRegistros(dataIso);
    return registros
      .filter((r) => r.colaboradorId === colaboradorId)
      .sort((a, b) => a.nsr - b.nsr);
  }

  async getInconsistencias(): Promise<AlertaInconsistencia[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('inconsistencias', 'readonly');
      const store = tx.objectStore('inconsistencias');
      const req = store.getAll();
      req.onsuccess = () => {
        const lista = (req.result as AlertaInconsistencia[]) || [];
        lista.sort((a, b) => new Date(b.criadoEm).getTime() - new Date(a.criadoEm).getTime());
        resolve(lista);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async salvarInconsistencia(alerta: AlertaInconsistencia): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('inconsistencias', 'readwrite');
      const store = tx.objectStore('inconsistencias');
      const req = store.put(alerta);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async resolverInconsistencia(id: string, observacaoRH: string): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('inconsistencias', 'readwrite');
      const store = tx.objectStore('inconsistencias');
      const req = store.get(id);
      req.onsuccess = () => {
        const item = req.result as AlertaInconsistencia;
        if (item) {
          item.resolvido = true;
          item.observacaoRH = observacaoRH;
          item.dataResolucao = new Date().toISOString();
          store.put(item);
        }
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getAtestados(): Promise<AtestadoMedico[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('atestados', 'readonly');
      const store = tx.objectStore('atestados');
      const req = store.getAll();
      req.onsuccess = () => {
        const lista = (req.result as AtestadoMedico[]) || [];
        lista.sort((a, b) => new Date(b.criadoEm).getTime() - new Date(a.criadoEm).getTime());
        resolve(lista);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async salvarAtestado(atestado: AtestadoMedico): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('atestados', 'readwrite');
      const store = tx.objectStore('atestados');
      const req = store.put(atestado);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // RN-04: Apuração de Faltas Automática
  // Verifica colaboradores ativos que não possuem nenhuma marcação e nem atestado no dia
  async apurarFaltasDoDia(dataIso: string): Promise<AlertaInconsistencia[]> {
    const colaboradores = await this.getColaboradores();
    const registros = await this.getRegistros(dataIso);
    const atestados = await this.getAtestados();
    const inconsistenciasExistentes = await this.getInconsistencias();

    const novasFaltas: AlertaInconsistencia[] = [];

    for (const colab of colaboradores) {
      if (!colab.ativo) continue;

      // Tem marcações no dia?
      const marcacoes = registros.filter((r) => r.colaboradorId === colab.id);
      if (marcacoes.length > 0) continue;

      // Tem atestado cobrindo esta data?
      const temAtestado = atestados.some(
        (a) =>
          a.colaboradorId === colab.id &&
          a.status === 'APROVADO' &&
          dataIso >= a.dataInicio &&
          dataIso <= a.dataFim
      );
      if (temAtestado) continue;

      // Já gerou alerta de falta hoje?
      const jaExiste = inconsistenciasExistentes.some(
        (inc) =>
          inc.colaboradorId === colab.id &&
          inc.dataIso === dataIso &&
          inc.tipo === 'FALTA_INJUSTIFICADA'
      );
      if (jaExiste) continue;

      const alertaFalta: AlertaInconsistencia = {
        id: `falta-${colab.id}-${dataIso}`,
        dataIso,
        colaboradorId: colab.id,
        colaboradorNome: colab.nome,
        cargo: colab.cargo,
        tipo: 'FALTA_INJUSTIFICADA',
        descricao: `Ausência total de marcações no expediente do dia ${dataIso.split('-').reverse().join('/')}. Registro automático de Falta Injustificada conforme RN-04.`,
        resolvido: false,
        criadoEm: new Date().toISOString(),
      };

      await this.salvarInconsistencia(alertaFalta);
      novasFaltas.push(alertaFalta);
    }

    return novasFaltas;
  }

  // RNF-01: Sincronização offline
  async marcarTodosComoSincronizados(): Promise<number> {
    const db = await this.open();
    return new Promise((resolve) => {
      const tx = db.transaction('registros', 'readwrite');
      const store = tx.objectStore('registros');
      const req = store.getAll();
      req.onsuccess = () => {
        const registros = (req.result as RegistroPonto[]) || [];
        let atualizados = 0;
        for (const reg of registros) {
          if (!reg.sincronizado) {
            reg.sincronizado = true;
            store.put(reg);
            atualizados++;
          }
        }
        resolve(atualizados);
      };
      req.onerror = () => resolve(0);
    });
  }
}

export const dbService = new DatabaseService();
