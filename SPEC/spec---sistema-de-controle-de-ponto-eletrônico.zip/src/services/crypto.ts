/**
 * RN-03: Imutabilidade do Registro
 * Geração de carimbo criptográfico SHA-256 auditável
 */

export async function gerarHashRegistro(
  nsr: number,
  colaboradorId: string,
  pis: string,
  tipoEvento: string,
  timestampUtc: string,
  metodo: string
): Promise<string> {
  const payload = `REP-P|NSR:${nsr}|COLAB:${colaboradorId}|PIS:${pis}|EVT:${tipoEvento}|UTC:${timestampUtc}|MET:${metodo}`;
  const encoder = new TextEncoder();
  const data = encoder.encode(payload);

  if (window.crypto && window.crypto.subtle) {
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  // Fallback se subtle crypto não estiver disponível
  let hash = 0;
  for (let i = 0; i < payload.length; i++) {
    const char = payload.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(64, 'A').toUpperCase();
}
