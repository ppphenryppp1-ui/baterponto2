/**
 * RN-01 & RN-02: Regras de Tolerância e Apuração de Variações de Horário
 * Portaria 671 MTE / Art. 58 § 1º CLT:
 * Não serão descontadas nem computadas como jornada extraordinária as variações
 * de horário no registro de ponto não excedentes a 5 (cinco) minutos, observado
 * o limite máximo de 10 (dez) minutos diários.
 */

import { Colaborador, RegistroPonto, TipoEventoPonto, TipoInconsistencia } from '../types';

export interface VerificacaoToleranciaResultado {
  excedeTolerancia: boolean;
  minutosVariacao: number; // minutos de atraso ou antecipação indesejada
  minutosAcumuladosHoje: number;
  motivoToleranciaExcedida?: string;
  tipoInconsistencia: TipoInconsistencia | 'NENHUMA';
}

function timeStringToMinutes(timeStr: string): number {
  const [hh, mm] = timeStr.split(':').map(Number);
  return (hh || 0) * 60 + (mm || 0);
}

export function verificarToleranciaEvento(
  colaborador: Colaborador,
  tipoEvento: TipoEventoPonto,
  horaRegistro: string, // formato "HH:mm" ou "HH:mm:ss"
  registrosDoDia: RegistroPonto[]
): VerificacaoToleranciaResultado {
  const horaLimpa = horaRegistro.slice(0, 5);
  const minutosAtual = timeStringToMinutes(horaLimpa);

  let horarioPrevistoStr = '';
  switch (tipoEvento) {
    case 'ENTRADA':
      horarioPrevistoStr = colaborador.jornadaPrevista.entrada;
      break;
    case 'SAIDA_INTERVALO':
      horarioPrevistoStr = colaborador.jornadaPrevista.saidaIntervalo;
      break;
    case 'RETORNO_INTERVALO':
      horarioPrevistoStr = colaborador.jornadaPrevista.retornoIntervalo;
      break;
    case 'SAIDA_EXPEDIENTE':
      horarioPrevistoStr = colaborador.jornadaPrevista.saidaExpediente;
      break;
  }

  const minutosPrevistos = timeStringToMinutes(horarioPrevistoStr);
  const diferencaBruta = minutosAtual - minutosPrevistos;

  let minutosVariacaoNegativa = 0; // minutos que prejudicam a jornada (atraso ou saída antes)
  let tipoInconsistencia: TipoInconsistencia | 'NENHUMA' = 'NENHUMA';

  if (tipoEvento === 'ENTRADA') {
    // Chegar depois do horário previsto
    if (diferencaBruta > 0) {
      minutosVariacaoNegativa = diferencaBruta;
      if (diferencaBruta > 5) {
        tipoInconsistencia = 'ATRASO_ENTRADA';
      }
    }
  } else if (tipoEvento === 'SAIDA_INTERVALO') {
    // Sair muito antes ou muito depois para intervalo
    if (Math.abs(diferencaBruta) > 15) {
      tipoInconsistencia = 'INTERVALO_IRREGULAR';
      minutosVariacaoNegativa = Math.abs(diferencaBruta);
    }
  } else if (tipoEvento === 'RETORNO_INTERVALO') {
    // Retornar tarde do almoço
    if (diferencaBruta > 0) {
      minutosVariacaoNegativa = diferencaBruta;
      if (diferencaBruta > 5) {
        tipoInconsistencia = 'INTERVALO_IRREGULAR';
      }
    }
  } else if (tipoEvento === 'SAIDA_EXPEDIENTE') {
    // Sair antes do horário previsto (diferencaBruta < 0)
    if (diferencaBruta < 0) {
      minutosVariacaoNegativa = Math.abs(diferencaBruta);
      if (minutosVariacaoNegativa > 5) {
        tipoInconsistencia = 'SAIDA_ANTECIPADA';
      }
    }
  }

  // Soma as variações dos outros registros já feitos hoje
  const variacoesAnteriores = registrosDoDia.reduce((acc, reg) => acc + (reg.minutosVariacao || 0), 0);
  const totalAcumuladoHoje = variacoesAnteriores + minutosVariacaoNegativa;

  // Regra RN-01:
  // 1) Se a marcação pontual passar de 5 min: excede tolerância
  // 2) Se o acumulado do dia passar de 10 min: excede tolerância
  const pontualExcedeu = minutosVariacaoNegativa > 5;
  const acumuladoExcedeu = totalAcumuladoHoje > 10;

  const excedeTolerancia = pontualExcedeu || acumuladoExcedeu;

  let motivo = '';
  if (pontualExcedeu && acumuladoExcedeu) {
    motivo = `Marcação excedeu os 5 min de tolerância (${minutosVariacaoNegativa} min) e o limite diário de 10 min acumulados (${totalAcumuladoHoje} min).`;
  } else if (pontualExcedeu) {
    motivo = `Marcação excedeu a tolerância permitida de 5 minutos (${minutosVariacaoNegativa} min de variação).`;
  } else if (acumuladoExcedeu) {
    motivo = `Limite acumulado diário de 10 minutos de variação ultrapassado (${totalAcumuladoHoje} min acumulados).`;
  }

  return {
    excedeTolerancia,
    minutosVariacao: minutosVariacaoNegativa,
    minutosAcumuladosHoje: totalAcumuladoHoje,
    motivoToleranciaExcedida: motivo,
    tipoInconsistencia: excedeTolerancia && tipoInconsistencia === 'NENHUMA' ? 'MARCACAO_FORA_FAIXA' : tipoInconsistencia,
  };
}
