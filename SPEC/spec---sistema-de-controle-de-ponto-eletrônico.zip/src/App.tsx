/**
 * SPEC - Sistema de Controle de Ponto Eletrônico (PWA Tablet/Desktop)
 * REP-P / Portaria MTE 671/2021
 */

import React, { useState, useEffect, useCallback } from 'react';
import { EmpresaConfig, HardwareState } from './types';
import { dbService } from './services/db';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { Header } from './components/Header';
import { KioskPonto } from './components/KioskPonto';
import { GestorPainel } from './components/GestorPainel';
import { ConsultaColaborador } from './components/ConsultaColaborador';
import { HardwareStatusModal } from './components/HardwareStatusModal';
import { ScreenNotice } from './components/ScreenNotice';
import { WifiOff } from 'lucide-react';

export default function App() {
  const isOnlineNativo = useOnlineStatus();
  const [activeTab, setActiveTab] = useState<'kiosk' | 'consult' | 'gestor'>('kiosk');
  const [showHardwareModal, setShowHardwareModal] = useState(false);

  const [hardware, setHardware] = useState<HardwareState>({
    impressoraStatus: 'OPERACIONAL',
    bobinaPorcentagem: 88,
    redeOnline: isOnlineNativo,
    cameraAtiva: true,
  });

  const [empresa, setEmpresa] = useState<EmpresaConfig>({
    razaoSocial: 'TECHSOLUTIONS INDÚSTRIA & TECNOLOGIA S.A.',
    nomeFantasia: 'TechSolutions REP Eletrônico',
    cnpj: '14.285.912/0001-44',
    endereco: 'Av. Paulista, 1842 - Bela Vista, São Paulo - SP, CEP 01310-923',
    registroMTE: 'REP-P Nº 849.201-SP (Portaria MTE 671/2021)',
    numeroEquipamento: 'EQP-PWA-00148',
  });

  const [inconsistenciasPendentesCount, setInconsistenciasPendentesCount] = useState(0);
  const [offlinePendingCount, setOfflinePendingCount] = useState(0);

  // Sincroniza estado de rede nativo quando ele mudar
  useEffect(() => {
    setHardware((prev) => ({
      ...prev,
      redeOnline: isOnlineNativo,
    }));
  }, [isOnlineNativo]);

  // Carrega configurações iniciais e contadores
  const atualizarContadores = useCallback(async () => {
    const config = await dbService.getEmpresaConfig();
    setEmpresa(config);

    const inconsistencias = await dbService.getInconsistencias();
    const pendentes = inconsistencias.filter((i) => !i.resolvido).length;
    setInconsistenciasPendentesCount(pendentes);

    const registros = await dbService.getRegistros();
    const naoSinc = registros.filter((r) => !r.sincronizado).length;
    setOfflinePendingCount(naoSinc);
  }, []);

  useEffect(() => {
    atualizarContadores();
  }, [atualizarContadores]);

  // Auto-sync quando a rede voltar (RNF-01)
  useEffect(() => {
    if (hardware.redeOnline && offlinePendingCount > 0) {
      dbService.marcarTodosComoSincronizados().then((qty) => {
        if (qty > 0) {
          atualizarContadores();
        }
      });
    }
  }, [hardware.redeOnline, offlinePendingCount, atualizarContadores]);

  const handleSyncManual = async () => {
    await dbService.marcarTodosComoSincronizados();
    await atualizarContadores();
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] text-slate-900 flex flex-col font-sans">
      
      {/* Alerta de resolução mínima para Tablet/Desktop (>= 768px) */}
      <ScreenNotice />

      {/* Banner não obstrutivo de Contingência Offline (RNF-01) */}
      {!hardware.redeOnline && (
        <div className="bg-amber-600 text-white px-4 py-1.5 text-xs font-semibold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 animate-pulse" />
            <span>
              <strong>Modo de Contingência Offline Ativo:</strong> As batidas de ponto estão sendo gravadas com segurança local no IndexedDB e serão sincronizadas automaticamente assim que a conexão for restabelecida.
            </span>
          </div>
          <span className="font-mono text-[11px] bg-amber-700 px-2 py-0.5 rounded">
            {offlinePendingCount} batida(s) pendente(s)
          </span>
        </div>
      )}

      {/* Cabeçalho Fixo com Indicadores de Rede e Impressora */}
      <Header
        hardware={hardware}
        onOpenHardwareModal={() => setShowHardwareModal(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        inconsistenciasNaoResolvidasCount={inconsistenciasPendentesCount}
      />

      {/* Conteúdo Principal */}
      <main className="flex-1 pb-10">
        {activeTab === 'kiosk' && (
          <KioskPonto
            empresa={empresa}
            hardware={hardware}
            onRegistroConcluido={atualizarContadores}
            onOpenHardwareModal={() => setShowHardwareModal(true)}
          />
        )}

        {activeTab === 'consult' && (
          <ConsultaColaborador
            empresa={empresa}
            hardware={hardware}
          />
        )}

        {activeTab === 'gestor' && (
          <GestorPainel
            empresa={empresa}
            onDataChanged={atualizarContadores}
          />
        )}
      </main>

      {/* Rodapé Corporativo de Conformidade REP-P */}
      <footer className="bg-white border-t border-slate-200 py-3 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            {empresa.razaoSocial} • CNPJ: {empresa.cnpj}
          </span>
          <span className="font-medium text-slate-600">
            {empresa.registroMTE} • PWA Offline-First
          </span>
        </div>
      </footer>

      {/* Modal de Diagnóstico e Simulação de Hardware (RF-08) */}
      {showHardwareModal && (
        <HardwareStatusModal
          hardware={hardware}
          setHardware={setHardware}
          onClose={() => setShowHardwareModal(false)}
          onSyncOffline={handleSyncManual}
          offlineCount={offlinePendingCount}
        />
      )}

    </div>
  );
}
