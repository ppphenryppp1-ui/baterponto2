import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  FileText,
  PlusCircle,
  Clock,
  UserCheck,
  UserX,
  Stethoscope,
  Download,
  Filter,
  Check,
  X,
  Search,
  RefreshCw,
} from 'lucide-react';
import {
  AlertaInconsistencia,
  AtestadoMedico,
  Colaborador,
  EmpresaConfig,
  RegistroPonto,
} from '../types';
import { dbService } from '../services/db';

interface GestorPainelProps {
  empresa: EmpresaConfig;
  onDataChanged: () => void;
}

export const GestorPainel: React.FC<GestorPainelProps> = ({ empresa, onDataChanged }) => {
  const [subTab, setSubTab] = useState<'inconsistencias' | 'atestados' | 'apuracao' | 'espelho'>('inconsistencias');
  const [inconsistencias, setInconsistencias] = useState<AlertaInconsistencia[]>([]);
  const [atestados, setAtestados] = useState<AtestadoMedico[]>([]);
  const [colaboradores, setColaboradores] = useState<Colaborador[]>([]);
  const [registros, setRegistros] = useState<RegistroPonto[]>([]);
  const [carregando, setCarregando] = useState(false);

  // Filtros
  const [filtroTipo, setFiltroTipo] = useState<string>('TODOS');
  const [apenasPendentes, setApenasPendentes] = useState<boolean>(true);

  // Modal de Resolução de Inconsistência
  const [inconsistenciaSelecionada, setInconsistenciaSelecionada] = useState<AlertaInconsistencia | null>(null);
  const [parecerRH, setParecerRH] = useState('');

  // Modal de Cadastro de Novo Atestado (RF-07)
  const [modalNovoAtestado, setModalNovoAtestado] = useState(false);
  const [novoAtestadoColabId, setNovoAtestadoColabId] = useState('');
  const [novoAtestadoInicio, setNovoAtestadoInicio] = useState(new Date().toISOString().split('T')[0]);
  const [novoAtestadoFim, setNovoAtestadoFim] = useState(new Date().toISOString().split('T')[0]);
  const [novoAtestadoDias, setNovoAtestadoDias] = useState(1);
  const [novoAtestadoCid, setNovoAtestadoCid] = useState('CID J06.9 - Infecções agudas das vias aéreas');
  const [novoAtestadoCrm, setNovoAtestadoCrm] = useState('CRM/SP 184.920');
  const [novoAtestadoMedico, setNovoAtestadoMedico] = useState('Dra. Amanda Nogueira');
  const [novoAtestadoMotivo, setNovoAtestadoMotivo] = useState('Repouso médico domiciliar por sintoma gripal');
  const [novoAtestadoNomeArquivo, setNovoAtestadoNomeArquivo] = useState('laudo_atestado_medico.pdf');

  // Apuração de Faltas (RN-04)
  const [mensagemApuracao, setMensagemApuracao] = useState('');

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setCarregando(true);
    try {
      const [incList, atestList, colabList, regList] = await Promise.all([
        dbService.getInconsistencias(),
        dbService.getAtestados(),
        dbService.getColaboradores(),
        dbService.getRegistros(),
      ]);
      setInconsistencias(incList);
      setAtestados(atestList);
      setColaboradores(colabList);
      setRegistros(regList);
      if (colabList.length > 0 && !novoAtestadoColabId) {
        setNovoAtestadoColabId(colabList[0].id);
      }
    } finally {
      setCarregando(false);
    }
  };

  // Resolver Inconsistência (RF-04)
  const handleResolverInconsistencia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inconsistenciaSelecionada) return;
    await dbService.resolverInconsistencia(
      inconsistenciaSelecionada.id,
      parecerRH || 'Justificativa analisada e homologada pelo RH.'
    );
    setInconsistenciaSelecionada(null);
    setParecerRH('');
    await carregarDados();
    onDataChanged();
  };

  // Salvar Novo Atestado Médico (RF-07)
  const handleSalvarAtestado = async (e: React.FormEvent) => {
    e.preventDefault();
    const colab = colaboradores.find((c) => c.id === novoAtestadoColabId);
    if (!colab) return;

    const atestado: AtestadoMedico = {
      id: `atest-${Date.now()}`,
      colaboradorId: colab.id,
      colaboradorNome: colab.nome,
      dataEmissao: new Date().toISOString().split('T')[0],
      dataInicio: novoAtestadoInicio,
      dataFim: novoAtestadoFim,
      diasAbono: Number(novoAtestadoDias) || 1,
      cid: novoAtestadoCid,
      medicoCrm: novoAtestadoCrm,
      medicoNome: novoAtestadoMedico,
      motivo: novoAtestadoMotivo,
      anexoNome: novoAtestadoNomeArquivo,
      status: 'APROVADO',
      criadoEm: new Date().toISOString(),
    };

    await dbService.salvarAtestado(atestado);
    setModalNovoAtestado(false);
    await carregarDados();
    onDataChanged();
  };

  // Executar Apuração de Faltas Diárias (RN-04)
  const handleExecutarApuracaoFaltas = async () => {
    const hoje = new Date().toISOString().split('T')[0];
    setCarregando(true);
    try {
      const faltasCriadas = await dbService.apurarFaltasDoDia(hoje);
      await carregarDados();
      onDataChanged();
      if (faltasCriadas.length > 0) {
        setMensagemApuracao(
          `RN-04 Concluída: ${faltasCriadas.length} falta(s) injustificada(s) apurada(s) e registradas automaticamente para o dia de hoje.`
        );
      } else {
        setMensagemApuracao('Todos os colaboradores ativos possuem marcação ou atestado homologado hoje.');
      }
    } finally {
      setCarregando(false);
    }
  };

  // Exportar Espelho de Ponto CSV
  const handleExportarCsv = () => {
    const headers = [
      'NSR',
      'Data',
      'Hora',
      'Colaborador',
      'PIS',
      'CPF',
      'Cargo',
      'Evento',
      'Metodo',
      'Excede_Tolerancia',
      'Minutos_Variacao',
      'Justificativa',
      'Hash_SHA256',
    ];

    const rows = registros.map((r) => [
      r.nsr,
      r.dataIso,
      r.horaLocal,
      `"${r.colaboradorNome}"`,
      r.pis,
      r.cpf,
      `"${r.cargo}"`,
      r.tipoEvento,
      r.metodoAutenticacao,
      r.excedeTolerancia ? 'SIM' : 'NAO',
      r.minutosVariacao,
      `"${r.justificativa || r.motivoJustificativa || ''}"`,
      r.hashSha256,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(';'), ...rows.map((e) => e.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `espelho_ponto_rep_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const inconsistenciasFiltradas = inconsistencias.filter((item) => {
    if (apenasPendentes && item.resolvido) return false;
    if (filtroTipo !== 'TODOS' && item.tipo !== filtroTipo) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Cabeçalho do Módulo de Gestão */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">
              Painel de Gestão e Auditoria de RH
            </h2>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
              Módulo Gestor
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitoramento em tempo real de inconsistências (RF-04), atestados médicos (RF-07) e fechamento de faltas (RN-04).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportarCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 transition"
          >
            <Download className="w-4 h-4" />
            <span>Exportar Relatório CSV</span>
          </button>

          <button
            onClick={() => setModalNovoAtestado(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-blue-700 hover:bg-blue-800 text-white shadow-xs transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Lançar Atestado (RF-07)</span>
          </button>
        </div>
      </div>

      {/* Sub-abas de Navegação */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setSubTab('inconsistencias')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            subTab === 'inconsistencias'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Inconsistências & Alertas ({inconsistencias.filter((i) => !i.resolvido).length} Pendentes)
        </button>

        <button
          onClick={() => setSubTab('atestados')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            subTab === 'atestados'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Gestão de Atestados & Abonos ({atestados.length})
        </button>

        <button
          onClick={() => setSubTab('apuracao')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            subTab === 'apuracao'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Apuração Diária de Faltas (RN-04)
        </button>

        <button
          onClick={() => setSubTab('espelho')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
            subTab === 'espelho'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Auditoria de Registros ({registros.length})
        </button>
      </div>

      {/* Aba 1: Inconsistências (RF-04) */}
      {subTab === 'inconsistencias' && (
        <div className="space-y-4">
          
          {/* Filtros */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 font-semibold text-slate-700">
                <input
                  type="checkbox"
                  checked={apenasPendentes}
                  onChange={(e) => setApenasPendentes(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span>Exibir apenas inconsistências pendentes</span>
              </label>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium">Filtrar por Tipo:</span>
              <select
                value={filtroTipo}
                onChange={(e) => setFiltroTipo(e.target.value)}
                className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 bg-white"
              >
                <option value="TODOS">Todos os Tipos</option>
                <option value="JUSTIFICATIVA_PENDENTE">Justificativas de Horário</option>
                <option value="ATRASO_ENTRADA">Atraso na Entrada</option>
                <option value="SAIDA_ANTECIPADA">Saída Antecipada</option>
                <option value="FALTA_INJUSTIFICADA">Faltas Injustificadas</option>
                <option value="INTERVALO_IRREGULAR">Intervalos Irregulares</option>
              </select>
            </div>
          </div>

          {/* Lista de Inconsistências */}
          {inconsistenciasFiltradas.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 text-slate-500">
              <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 mb-2" />
              <p className="font-bold text-slate-800 text-sm">Nenhuma inconsistência pendente encontrada.</p>
              <p className="text-xs text-slate-500 mt-1">Todos os registros e justificativas foram regularizados.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {inconsistenciasFiltradas.map((inc) => (
                <div
                  key={inc.id}
                  className={`bg-white p-5 rounded-xl border transition shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    inc.resolvido ? 'border-slate-200 bg-slate-50/50' : 'border-amber-300 bg-amber-50/20'
                  }`}
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          inc.resolvido
                            ? 'bg-slate-200 text-slate-700'
                            : inc.tipo === 'FALTA_INJUSTIFICADA'
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-amber-100 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {inc.tipo.replace('_', ' ')}
                      </span>
                      <span className="text-xs font-bold text-slate-900">{inc.colaboradorNome}</span>
                      <span className="text-xs text-slate-500">({inc.cargo})</span>
                    </div>

                    <p className="text-xs text-slate-700">{inc.descricao}</p>

                    {inc.resolvido && inc.observacaoRH && (
                      <div className="text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded border border-emerald-200">
                        <strong>Parecer RH:</strong> {inc.observacaoRH}
                        <span className="text-slate-500 ml-2">
                          (Resolvido em {new Date(inc.dataResolucao || '').toLocaleString('pt-BR')})
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {!inc.resolvido ? (
                      <button
                        onClick={() => {
                          setInconsistenciaSelecionada(inc);
                          setParecerRH('');
                        }}
                        className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-lg shadow-xs transition"
                      >
                        Tratar Alerta (RH)
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-md">
                        <Check className="w-3.5 h-3.5" /> Resolvido
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* Aba 2: Gestão de Atestados e Abonos (RF-07) */}
      {subTab === 'atestados' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {atestados.map((atest) => (
              <div key={atest.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-sky-100 text-sky-800">
                      <Stethoscope className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{atest.colaboradorNome}</h4>
                      <p className="text-[11px] text-slate-500">{atest.diasAbono} dia(s) abonado(s)</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {atest.status}
                  </span>
                </div>

                <div className="text-xs text-slate-600 space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div><strong>Período:</strong> {atest.dataInicio.split('-').reverse().join('/')} até {atest.dataFim.split('-').reverse().join('/')}</div>
                  <div><strong>CID:</strong> {atest.cid}</div>
                  <div><strong>Médico:</strong> {atest.medicoNome} ({atest.medicoCrm})</div>
                  <div><strong>Motivo:</strong> {atest.motivo}</div>
                  {atest.anexoNome && (
                    <div className="text-[11px] text-blue-700 font-mono flex items-center gap-1 pt-1">
                      <FileText className="w-3 h-3" />
                      <span>{atest.anexoNome}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Aba 3: Apuração Diária de Faltas (RN-04) */}
      {subTab === 'apuracao' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="max-w-2xl space-y-2">
            <h3 className="text-base font-bold text-slate-900">
              RN-04: Apuração e Registro Automático de Faltas
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              A regra de negócio <strong>RN-04</strong> preconiza que a ausência total de marcações de ponto ao final do expediente seja convertida automaticamente em <strong>Falta Injustificada</strong>, notificando o gestor para auditoria na folha de pagamento, exceto se houver atestado médico homologado para o dia.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExecutarApuracaoFaltas}
              disabled={carregando}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition shadow-xs"
            >
              <RefreshCw className={`w-4 h-4 ${carregando ? 'animate-spin' : ''}`} />
              <span>Executar Apuração Diária de Faltas Agora</span>
            </button>
          </div>

          {mensagemApuracao && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{mensagemApuracao}</span>
            </div>
          )}

          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
              Quadro Geral de Colaboradores Cadastrados
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {colaboradores.map((colab) => {
                const hoje = new Date().toISOString().split('T')[0];
                const marcouHoje = registros.some((r) => r.colaboradorId === colab.id && r.dataIso === hoje);
                const temAtestadoHoje = atestados.some(
                  (a) => a.colaboradorId === colab.id && a.status === 'APROVADO' && hoje >= a.dataInicio && hoje <= a.dataFim
                );

                return (
                  <div key={colab.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-slate-900 block">{colab.nome}</span>
                      <span className="text-[11px] text-slate-500">{colab.cargo}</span>
                    </div>
                    <div>
                      {marcouHoje ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                          <UserCheck className="w-3 h-3" /> Ponto Batido
                        </span>
                      ) : temAtestadoHoje ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-sky-700 bg-sky-100 px-2 py-0.5 rounded">
                          <Stethoscope className="w-3 h-3" /> Atestado
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                          <UserX className="w-3 h-3" /> Sem Registro
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Aba 4: Espelho Completo de Registros Imutáveis (RN-03) */}
      {subTab === 'espelho' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between text-xs">
            <h4 className="font-bold text-slate-900 uppercase tracking-wider">
              Registros Fiscais Imutáveis REP-P (Conformidade Portaria 671)
            </h4>
            <span className="font-mono text-slate-500">Total: {registros.length} marcações</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">NSR</th>
                  <th className="py-3 px-4">Data / Hora Local</th>
                  <th className="py-3 px-4">Colaborador</th>
                  <th className="py-3 px-4">PIS</th>
                  <th className="py-3 px-4">Evento</th>
                  <th className="py-3 px-4">Autenticação</th>
                  <th className="py-3 px-4">Tolerância</th>
                  <th className="py-3 px-4">Assinatura SHA-256</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {registros.map((reg) => (
                  <tr key={reg.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-4 font-mono font-bold">{reg.nsr}</td>
                    <td className="py-2.5 px-4">
                      {reg.dataIso.split('-').reverse().join('/')} às <strong>{reg.horaLocal}</strong>
                    </td>
                    <td className="py-2.5 px-4 font-semibold">{reg.colaboradorNome}</td>
                    <td className="py-2.5 px-4 font-mono text-[11px] text-slate-500">{reg.pis}</td>
                    <td className="py-2.5 px-4">
                      <span className="bg-slate-100 px-2 py-0.5 rounded font-bold text-[10px]">
                        {reg.tipoEvento}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-[11px]">{reg.metodoAutenticacao}</td>
                    <td className="py-2.5 px-4">
                      {reg.excedeTolerancia ? (
                        <span className="text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded font-bold text-[10px]">
                          +{reg.minutosVariacao}m
                        </span>
                      ) : (
                        <span className="text-emerald-700 text-[10px]">Normal</span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-[9px] text-slate-500 truncate max-w-xs" title={reg.hashSha256}>
                      {reg.hashSha256.substring(0, 16)}...
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal para Tratar Inconsistência */}
      {inconsistenciaSelecionada && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold">Tratar Inconsistência de Ponto (RH)</h3>
              <button onClick={() => setInconsistenciaSelecionada(null)}>
                <X className="w-5 h-5 text-slate-400 hover:text-white" />
              </button>
            </div>

            <form onSubmit={handleResolverInconsistencia} className="p-6 space-y-4">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                <div><strong>Colaborador:</strong> {inconsistenciaSelecionada.colaboradorNome}</div>
                <div><strong>Tipo:</strong> {inconsistenciaSelecionada.tipo}</div>
                <div><strong>Detalhes:</strong> {inconsistenciaSelecionada.descricao}</div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Parecer e Observação do RH (Obrigatório)
                </label>
                <textarea
                  value={parecerRH}
                  onChange={(e) => setParecerRH(e.target.value)}
                  placeholder="Ex: Justificativa aceita e homologada sem desconto em folha..."
                  rows={3}
                  className="w-full border border-slate-300 rounded-lg p-3 text-xs outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setInconsistenciaSelecionada(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-300"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-xs"
                >
                  Confirmar Resolução
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Lançar Atestado (RF-07) */}
      {modalNovoAtestado && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-sky-400" />
                <h3 className="text-sm font-bold">RF-07: Lançamento de Atestado Médico</h3>
              </div>
              <button onClick={() => setModalNovoAtestado(false)}>
                <X className="w-5 h-5 text-slate-400 hover:text-white" />
              </button>
            </div>

            <form onSubmit={handleSalvarAtestado} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">Colaborador</label>
                <select
                  value={novoAtestadoColabId}
                  onChange={(e) => setNovoAtestadoColabId(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold bg-white"
                >
                  {colaboradores.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nome} ({c.cargo})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Data Início</label>
                  <input
                    type="date"
                    value={novoAtestadoInicio}
                    onChange={(e) => setNovoAtestadoInicio(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Data Fim</label>
                  <input
                    type="date"
                    value={novoAtestadoFim}
                    onChange={(e) => setNovoAtestadoFim(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Dias de Abono</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={novoAtestadoDias}
                    onChange={(e) => setNovoAtestadoDias(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Código CID</label>
                  <input
                    type="text"
                    value={novoAtestadoCid}
                    onChange={(e) => setNovoAtestadoCid(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Médico Emitente</label>
                  <input
                    type="text"
                    value={novoAtestadoMedico}
                    onChange={(e) => setNovoAtestadoMedico(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">CRM / UF</label>
                  <input
                    type="text"
                    value={novoAtestadoCrm}
                    onChange={(e) => setNovoAtestadoCrm(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">Motivo / Prescrição</label>
                <textarea
                  value={novoAtestadoMotivo}
                  onChange={(e) => setNovoAtestadoMotivo(e.target.value)}
                  rows={2}
                  className="w-full border border-slate-300 rounded-lg p-2.5 text-xs outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalNovoAtestado(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-300"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-xs"
                >
                  Salvar e Abonar Período
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
