import React, { useState } from 'react';
import { AlertTriangle, Clock, ShieldAlert, FileText, CheckCircle2 } from 'lucide-react';
import { Colaborador, TipoEventoPonto } from '../types';

interface JustificativaModalProps {
  colaborador: Colaborador;
  tipoEvento: TipoEventoPonto;
  motivoTolerancia: string;
  minutosVariacao: number;
  onConfirmar: (motivoPadrao: string, descricaoTexto: string) => void;
  onCancelar: () => void;
}

const MOTIVOS_PADRAO = [
  'Trânsito / Atraso de Transporte Público',
  'Consulta Médica / Realização de Exames',
  'Problema Técnico no Equipamento / Acesso',
  'Reunião Externa ou Atendimento a Cliente',
  'Problemas Pessoais ou Força Maior',
  'Compensação de Horário Pré-Autorizada',
  'Outro Motivo Específico',
];

export const JustificativaModal: React.FC<JustificativaModalProps> = ({
  colaborador,
  tipoEvento,
  motivoTolerancia,
  minutosVariacao,
  onConfirmar,
  onCancelar,
}) => {
  const [motivoSelecionado, setMotivoSelecionado] = useState(MOTIVOS_PADRAO[0]);
  const [descricao, setDescricao] = useState('');
  const [erroValidacao, setErroValidacao] = useState('');

  const handleSalvar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!descricao.trim() || descricao.trim().length < 5) {
      setErroValidacao('Por favor, informe uma descrição detalhada de ao menos 5 caracteres.');
      return;
    }
    onConfirmar(motivoSelecionado, descricao.trim());
  };

  const getNomeEvento = (evento: TipoEventoPonto) => {
    switch (evento) {
      case 'ENTRADA':
        return 'Entrada';
      case 'SAIDA_INTERVALO':
        return 'Saída para Intervalo';
      case 'RETORNO_INTERVALO':
        return 'Retorno do Intervalo';
      case 'SAIDA_EXPEDIENTE':
        return 'Saída do Expediente';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Cabeçalho de Alerta RF-03 */}
        <div className="bg-amber-600 text-white px-6 py-4 flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-amber-200 shrink-0" />
          <div>
            <h3 className="text-base font-bold">RF-03: Justificativa Obrigatória de Horário</h3>
            <p className="text-xs text-amber-100">
              Variação de horário excedeu o limite legal estipulado pela Portaria 671 e CLT
            </p>
          </div>
        </div>

        <form onSubmit={handleSalvar} className="p-6 space-y-4">
          
          {/* Card com Detalhes da Variação (RN-01 & RN-02) */}
          <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 text-xs text-amber-900 space-y-2">
            <div className="flex items-center justify-between font-semibold">
              <span>Colaborador: {colaborador.nome}</span>
              <span className="bg-amber-200 text-amber-950 px-2 py-0.5 rounded font-mono">
                {getNomeEvento(tipoEvento)}
              </span>
            </div>
            <div className="text-xs text-amber-800 font-medium">
              {motivoTolerancia}
            </div>
            <div className="text-[11px] text-amber-700">
              Conforme as regras de negócio <strong>RN-01</strong> e <strong>RN-02</strong>, qualquer marcação que ultrapasse 5 min por evento ou 10 min acumulados requer justificativa documentada e será alertada no painel do gestor (RF-04).
            </div>
          </div>

          {/* Seleção do Motivo Padronizado */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
              Motivo Principal
            </label>
            <select
              value={motivoSelecionado}
              onChange={(e) => setMotivoSelecionado(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
            >
              {MOTIVOS_PADRAO.map((motivo) => (
                <option key={motivo} value={motivo}>
                  {motivo}
                </option>
              ))}
            </select>
          </div>

          {/* Campo de Detalhamento Obrigatório */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
              Detalhamento / Observações (Obrigatório)
            </label>
            <textarea
              value={descricao}
              onChange={(e) => {
                setDescricao(e.target.value);
                setErroValidacao('');
              }}
              placeholder="Descreva o motivo da divergência de horário para validação do RH..."
              rows={3}
              className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-900 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
            />
            {erroValidacao && (
              <p className="text-xs text-rose-600 font-semibold mt-1">{erroValidacao}</p>
            )}
          </div>

          {/* Ações */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onCancelar}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-300 transition"
            >
              Cancelar Marcação
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-sm transition"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Gravar Ponto com Justificativa</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
