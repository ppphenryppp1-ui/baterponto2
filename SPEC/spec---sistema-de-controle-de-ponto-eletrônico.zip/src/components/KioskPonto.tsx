import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  CameraOff,
  Clock,
  KeyRound,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  User,
  ShieldCheck,
  ChevronRight,
  RefreshCw,
  Printer,
  Mail,
  Zap,
} from 'lucide-react';
import {
  Colaborador,
  EmpresaConfig,
  HardwareState,
  MetodoAutenticacao,
  RegistroPonto,
  TipoEventoPonto,
} from '../types';
import { dbService } from '../services/db';
import { audioService } from '../services/audio';
import { gerarHashRegistro } from '../services/crypto';
import { verificarToleranciaEvento } from '../services/tolerance';
import { JustificativaModal } from './JustificativaModal';
import { TicketTermicoModal } from './TicketTermicoModal';

interface KioskPontoProps {
  empresa: EmpresaConfig;
  hardware: HardwareState;
  onRegistroConcluido: () => void;
  onOpenHardwareModal: () => void;
}

export const KioskPonto: React.FC<KioskPontoProps> = ({
  empresa,
  hardware,
  onRegistroConcluido,
  onOpenHardwareModal,
}) => {
  const [colaboradores, setColaboradores] = useState<Colaborador[]>([]);
  const [colaboradorSelecionado, setColaboradorSelecionado] = useState<Colaborador | null>(null);
  const [metodoAuth, setMetodoAuth] = useState<MetodoAutenticacao>('BIOMETRIA_FACIAL');
  const [pinInput, setPinInput] = useState<string>('');
  const [rfidInput, setRfidInput] = useState<string>('');
  const [mensagemErro, setMensagemErro] = useState<string>('');
  const [registrosHoje, setRegistrosHoje] = useState<RegistroPonto[]>([]);
  const [processandoRegistro, setProcessandoRegistro] = useState(false);

  // Estados de Modais
  const [justificativaPendente, setJustificativaPendente] = useState<{
    evento: TipoEventoPonto;
    motivoTolerancia: string;
    minutosVariacao: number;
    fotoBase64?: string;
  } | null>(null);

  const [ticketModalRegistro, setTicketModalRegistro] = useState<RegistroPonto | null>(null);

  // Câmera Nativa getUserMedia (RF-05)
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [cameraAtiva, setCameraAtiva] = useState(false);
  const [cameraPermissaoNegada, setCameraPermissaoNegada] = useState(false);
  const streamRef = useRef<MediaStream | null>(null);

  // Carrega Colaboradores
  useEffect(() => {
    carregarColaboradores();
  }, []);

  const carregarColaboradores = async () => {
    const list = await dbService.getColaboradores();
    setColaboradores(list);
    if (list.length > 0 && !colaboradorSelecionado) {
      setColaboradorSelecionado(list[0]);
    }
  };

  // Carrega registros de hoje do colaborador selecionado
  useEffect(() => {
    if (colaboradorSelecionado) {
      const hoje = new Date().toISOString().split('T')[0];
      dbService.getRegistrosDoColaboradorNoDia(colaboradorSelecionado.id, hoje).then((regs) => {
        setRegistrosHoje(regs);
      });
    }
  }, [colaboradorSelecionado]);

  // Inicia Câmera quando método for Biometria Facial
  useEffect(() => {
    let montado = true;

    const startCamera = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setCameraPermissaoNegada(true);
          return;
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'user',
            width: { ideal: 640 },
            height: { ideal: 480 },
          },
          audio: false,
        });

        if (!montado) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
        setCameraAtiva(true);
        setCameraPermissaoNegada(false);
      } catch (err) {
        console.warn('Câmera indisponível ou permissão não concedida:', err);
        setCameraPermissaoNegada(true);
        setCameraAtiva(false);
      }
    };

    if (metodoAuth === 'BIOMETRIA_FACIAL') {
      startCamera();
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      setCameraAtiva(false);
    }

    return () => {
      montado = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [metodoAuth]);

  // Captura foto instantânea do vídeo
  const capturarFotoCanvas = (): string => {
    if (videoRef.current && cameraAtiva) {
      try {
        const video = videoRef.current;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          return canvas.toDataURL('image/jpeg', 0.85);
        }
      } catch (e) {
        console.warn('Erro ao capturar snapshot de canvas:', e);
      }
    }
    // Fallback para simulação visual de snapshot
    return '';
  };

  // Teclado numérico PIN (RF-06)
  const handlePinKeyPress = (num: string) => {
    if (pinInput.length < 6) {
      setPinInput((prev) => prev + num);
      setMensagemErro('');
    }
  };

  const handlePinBackspace = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setMensagemErro('');
  };

  const handlePinClear = () => {
    setPinInput('');
    setMensagemErro('');
  };

  const handlePinSubmit = async () => {
    if (!pinInput) {
      setMensagemErro('Digite o PIN de segurança.');
      return;
    }
    const achado = await dbService.getColaboradorByPin(pinInput);
    if (!achado) {
      audioService.playWarningBeep();
      setMensagemErro('PIN de segurança incorreto ou não localizado.');
      return;
    }
    setColaboradorSelecionado(achado);
    setMensagemErro('');
  };

  const handleRfidSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rfidInput.trim()) return;
    const achado = await dbService.getColaboradorByRfid(rfidInput);
    if (!achado) {
      audioService.playWarningBeep();
      setMensagemErro('Cartão RFID / Crachá não cadastrado.');
      return;
    }
    setColaboradorSelecionado(achado);
    setMensagemErro('');
    setRfidInput('');
  };

  // Acionamento de um dos 4 eventos de ponto (RF-01)
  const handleBaterPonto = async (tipoEvento: TipoEventoPonto) => {
    if (!colaboradorSelecionado) {
      setMensagemErro('Selecione um colaborador para registrar o ponto.');
      return;
    }

    if (processandoRegistro) return;
    setProcessandoRegistro(true);
    setMensagemErro('');

    try {
      const agora = new Date();
      const horaLocal = agora.toLocaleTimeString('pt-BR', { hour12: false });
      const hojeIso = agora.toISOString().split('T')[0];

      // RN-01 & RN-02: Verificação de tolerância
      const regsDoDia = await dbService.getRegistrosDoColaboradorNoDia(
        colaboradorSelecionado.id,
        hojeIso
      );
      const resultadoTolerancia = verificarToleranciaEvento(
        colaboradorSelecionado,
        tipoEvento,
        horaLocal,
        regsDoDia
      );

      const fotoCapturada = capturarFotoCanvas();

      // Se excedeu a tolerância, abre obrigatoriamente modal de justificativa (RF-03)
      if (resultadoTolerancia.excedeTolerancia) {
        audioService.playWarningBeep();
        setJustificativaPendente({
          evento: tipoEvento,
          motivoTolerancia: resultadoTolerancia.motivoToleranciaExcedida || 'Tolerância excedida',
          minutosVariacao: resultadoTolerancia.minutosVariacao,
          fotoBase64: fotoCapturada,
        });
        setProcessandoRegistro(false);
        return;
      }

      // Se dentro da tolerância, grava diretamente em sub-segundo (RNF-02)
      await finalizarGravacaoPonto(
        tipoEvento,
        resultadoTolerancia.minutosVariacao,
        false,
        undefined,
        undefined,
        fotoCapturada
      );
    } catch (err) {
      console.error('Erro ao processar ponto:', err);
      setMensagemErro('Falha ao gravar ponto. Tente novamente.');
    } finally {
      setProcessandoRegistro(false);
    }
  };

  // Gravação final no IndexedDB e emissão de comprovante (RF-02 / RF-09 / RN-03)
  const finalizarGravacaoPonto = async (
    tipoEvento: TipoEventoPonto,
    minutosVariacao: number,
    excedeTolerancia: boolean,
    motivoJustificativa?: string,
    justificativaTexto?: string,
    fotoCapturada?: string
  ) => {
    if (!colaboradorSelecionado) return;

    const agora = new Date();
    const dataIso = agora.toISOString().split('T')[0];
    const timestampUtc = agora.toISOString();
    const horaLocal = agora.toLocaleTimeString('pt-BR', { hour12: false });
    const timestampLocal = agora.toLocaleString('pt-BR');

    const proximoNsr = await dbService.getProximoNsr();

    // RN-03: Hash Criptográfico SHA-256 Imutável
    const hash = await gerarHashRegistro(
      proximoNsr,
      colaboradorSelecionado.id,
      colaboradorSelecionado.pis,
      tipoEvento,
      timestampUtc,
      metodoAuth
    );

    // Modo de comprovante
    let modoComprovante: 'IMPRESSO' | 'DIGITAL_EMAIL' | 'AMBOS' = 'IMPRESSO';
    if (hardware.impressoraStatus !== 'OPERACIONAL') {
      modoComprovante = 'DIGITAL_EMAIL';
    }

    const novoRegistro: RegistroPonto = {
      id: `reg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      nsr: proximoNsr,
      colaboradorId: colaboradorSelecionado.id,
      colaboradorNome: colaboradorSelecionado.nome,
      pis: colaboradorSelecionado.pis,
      cpf: colaboradorSelecionado.cpf,
      cargo: colaboradorSelecionado.cargo,
      tipoEvento,
      timestampUtc,
      timestampLocal,
      dataIso,
      horaLocal,
      metodoAutenticacao: metodoAuth,
      fotoBase64: fotoCapturada || undefined,
      hashSha256: hash,
      sincronizado: hardware.redeOnline,
      comprovanteEmitido: true,
      modoComprovante,
      emailEnviadoPara: colaboradorSelecionado.email,
      excedeTolerancia,
      minutosVariacao,
      motivoJustificativa,
      justificativa: justificativaTexto,
    };

    // Salva no IndexedDB
    await dbService.salvarRegistro(novoRegistro);

    // Se houve inconsistência ou justificativa, grava alerta para o gestor (RF-04)
    if (excedeTolerancia) {
      await dbService.salvarInconsistencia({
        id: `inc-${novoRegistro.id}`,
        dataIso,
        colaboradorId: colaboradorSelecionado.id,
        colaboradorNome: colaboradorSelecionado.nome,
        cargo: colaboradorSelecionado.cargo,
        tipo: 'JUSTIFICATIVA_PENDENTE',
        descricao: `Marcação de ${tipoEvento} com variação de ${minutosVariacao} min. Motivo: ${motivoJustificativa}. Detalhe: "${justificativaTexto}".`,
        registroPontoId: novoRegistro.id,
        resolvido: false,
        criadoEm: timestampUtc,
      });
    }

    // Feedback acústico regulamentar (RNF-02)
    audioService.playSuccessBeep();

    // Atualiza lista local de batidas de hoje
    const regsAtualizados = await dbService.getRegistrosDoColaboradorNoDia(
      colaboradorSelecionado.id,
      dataIso
    );
    setRegistrosHoje(regsAtualizados);

    // Abre o ticket térmico fiscal para visualização e impressão
    setTicketModalRegistro(novoRegistro);

    // Notifica componente pai
    onRegistroConcluido();
  };

  // Callback de confirmação de justificativa (RF-03)
  const handleConfirmarJustificativa = async (motivo: string, texto: string) => {
    if (!justificativaPendente) return;
    const pendente = justificativaPendente;
    setJustificativaPendente(null);

    await finalizarGravacaoPonto(
      pendente.evento,
      pendente.minutosVariacao,
      true,
      motivo,
      texto,
      pendente.fotoBase64
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Mensagem de Erro / Alerta Visual de Hardware */}
      {mensagemErro && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-center justify-between text-xs font-semibold shadow-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{mensagemErro}</span>
          </div>
          <button
            onClick={() => setMensagemErro('')}
            className="text-rose-600 hover:text-rose-900 font-bold"
          >
            Dispensar
          </button>
        </div>
      )}

      {/* Alerta de Hardware da Impressora (RF-08) */}
      {hardware.impressoraStatus !== 'OPERACIONAL' && (
        <div
          onClick={onOpenHardwareModal}
          className="bg-amber-50 border border-amber-300 text-amber-900 p-3.5 rounded-xl flex items-center justify-between text-xs cursor-pointer shadow-xs"
        >
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <div>
              <span className="font-bold">Aviso de Hardware (RF-08):</span> Impressora está{' '}
              <strong className="text-rose-700">
                {hardware.impressoraStatus === 'SEM_PAPEL' ? 'SEM PAPEL / BOBINA ESGOTADA' : 'EM DEFEITO'}
              </strong>
              . Tickets serão transmitidos automaticamente por e-mail (RF-09).
            </div>
          </div>
          <span className="font-semibold text-blue-700 underline text-[11px]">
            Verificar Hardware
          </span>
        </div>
      )}

      {/* Grid Principal do Quiosque (Otimizado para Tablets >= 768px em Paisagem ou Retrato) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Coluna Esquerda: Câmera Nativa / Teclado de Exceção (5 colunas no Desktop) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Seletor de Método de Identificação */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 px-1">
              Método de Autenticação (RF-05 / RF-06)
            </div>
            <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  setMetodoAuth('BIOMETRIA_FACIAL');
                  setMensagemErro('');
                }}
                className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition ${
                  metodoAuth === 'BIOMETRIA_FACIAL'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Facial (RF-05)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMetodoAuth('PIN');
                  setMensagemErro('');
                }}
                className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition ${
                  metodoAuth === 'PIN'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>PIN (RF-06)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMetodoAuth('RFID_CARTAO');
                  setMensagemErro('');
                }}
                className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition ${
                  metodoAuth === 'RFID_CARTAO'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>RFID / Crachá</span>
              </button>
            </div>
          </div>

          {/* Área da Câmera Facial (RF-05) */}
          {metodoAuth === 'BIOMETRIA_FACIAL' && (
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-sky-600" />
                  Validação Facial em Tempo Real
                </span>
                <span className="text-[10px] font-mono uppercase bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
                  Sensor Ativo
                </span>
              </div>

              {/* Viewport da Câmera com Guia Oval Biométrico */}
              <div className="relative aspect-4/3 bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center shadow-inner">
                {cameraAtiva && !cameraPermissaoNegada ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover -scale-x-100"
                  />
                ) : (
                  <div className="text-center p-6 space-y-3 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-500">
                      <CameraOff className="w-8 h-8" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-300">
                        {cameraPermissaoNegada ? 'Câmera Não Autorizada ou Sem Acesso' : 'Iniciando sensor de câmera...'}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
                        Permita a permissão de câmera no navegador ou utilize o modo de exceção por PIN / RFID.
                      </p>
                    </div>
                  </div>
                )}

                {/* Moldura Guia Oval de Reconhecimento Facial */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-44 h-56 border-2 border-dashed border-sky-400/80 rounded-[50%] flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.2)]">
                    <span className="text-[10px] uppercase font-mono font-bold text-sky-300/80 bg-black/40 px-2 py-0.5 rounded backdrop-blur-xs">
                      Enquadre o Rosto
                    </span>
                  </div>
                </div>

                {/* Status Bar Flutuante */}
                <div className="absolute bottom-2 left-2 right-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg flex items-center justify-between text-[11px] text-white">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Reconhecimento Biométrico Ativo
                  </span>
                  <span className="font-mono text-slate-300">Sub-segundo</span>
                </div>
              </div>

              {/* Seletor Rápido de Colaborador para Teste no Terminal */}
              <div className="pt-1">
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Colaborador Identificado pelo Sensor:
                </label>
                <select
                  value={colaboradorSelecionado?.id || ''}
                  onChange={(e) => {
                    const sel = colaboradores.find((c) => c.id === e.target.value);
                    if (sel) setColaboradorSelecionado(sel);
                  }}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-sky-500 outline-none"
                >
                  {colaboradores.map((colab) => (
                    <option key={colab.id} value={colab.id}>
                      {colab.nome} - {colab.cargo} ({colab.pis})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Modo de Exceção: Teclado Touch Numérico de PIN (RF-06) */}
          {metodoAuth === 'PIN' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="text-center space-y-1">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Autenticação de Exceção por PIN (RF-06)
                </h4>
                <p className="text-[11px] text-slate-500">
                  Digite seu PIN pessoal de 4 a 6 dígitos cadastrado no RH
                </p>
              </div>

              {/* Display do PIN */}
              <div className="bg-slate-100 h-12 rounded-xl flex items-center justify-center tracking-widest font-mono text-2xl font-bold text-slate-900 border border-slate-200">
                {pinInput ? '•'.repeat(pinInput.length) : <span className="text-xs text-slate-400 font-normal">Digite o PIN no teclado</span>}
              </div>

              {/* Teclado Virtual Numérico Otimizado para Tablet Touch */}
              <div className="grid grid-cols-3 gap-2">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handlePinKeyPress(num)}
                    className="h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-900 font-mono text-lg font-bold rounded-xl border border-slate-200 shadow-2xs transition"
                  >
                    {num}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={handlePinClear}
                  className="h-12 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition"
                >
                  Limpar
                </button>
                <button
                  type="button"
                  onClick={() => handlePinKeyPress('0')}
                  className="h-12 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-900 font-mono text-lg font-bold rounded-xl border border-slate-200 shadow-2xs transition"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={handlePinBackspace}
                  className="h-12 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition"
                >
                  Apagar
                </button>
              </div>

              <button
                type="button"
                onClick={handlePinSubmit}
                disabled={pinInput.length < 4}
                className="w-full py-2.5 bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl transition shadow-xs"
              >
                Validar PIN
              </button>

              <div className="text-[11px] text-center text-slate-500">
                PIN de demonstração: <strong>1234</strong> (Carlos), <strong>4321</strong> (Mariana), <strong>7788</strong> (Roberto)
              </div>
            </div>
          )}

          {/* Modo de Exceção: RFID / Crachá de Aproximação (RF-06) */}
          {metodoAuth === 'RFID_CARTAO' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="text-center space-y-1">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Leitor de Cartão de Proximidade RFID (RF-06)
                </h4>
                <p className="text-[11px] text-slate-500">
                  Aproxime o crachá funcional ou digite o identificador da tag RFID
                </p>
              </div>

              <div className="w-24 h-24 rounded-2xl bg-sky-50 border-2 border-dashed border-sky-300 mx-auto flex items-center justify-center text-sky-700">
                <CreditCard className="w-10 h-10" />
              </div>

              <form onSubmit={handleRfidSubmit} className="space-y-3">
                <input
                  type="text"
                  placeholder="Ex: TAG-9941 ou TAG-8823..."
                  value={rfidInput}
                  onChange={(e) => setRfidInput(e.target.value)}
                  className="w-full text-center font-mono font-bold text-slate-900 border border-slate-300 rounded-xl px-4 py-2.5 text-xs outline-none focus:ring-2 focus:ring-sky-500"
                />
                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl transition shadow-xs"
                >
                  Simular Leitura do Crachá
                </button>
              </form>

              <div className="text-[11px] text-center text-slate-500">
                Tags de demonstração: <strong>TAG-9941</strong> (Carlos), <strong>TAG-8823</strong> (Mariana), <strong>TAG-4412</strong> (Roberto)
              </div>
            </div>
          )}

        </div>

        {/* Coluna Direita: Cartão do Colaborador & 4 Botões de Evento (7 colunas no Desktop) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Card de Identificação do Colaborador */}
          {colaboradorSelecionado ? (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3.5">
                  <div className="w-13 h-13 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-lg shadow-xs">
                    {colaboradorSelecionado.nome
                      .split(' ')
                      .slice(0, 2)
                      .map((n) => n[0])
                      .join('')}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      {colaboradorSelecionado.nome}
                    </h3>
                    <p className="text-xs text-slate-600 font-medium">
                      {colaboradorSelecionado.cargo} • {colaboradorSelecionado.departamento}
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                      PIS: {colaboradorSelecionado.pis} | CPF: {colaboradorSelecionado.cpf}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-block bg-sky-50 border border-sky-200 text-sky-800 text-[11px] font-semibold px-2.5 py-1 rounded-lg">
                    Turno: {colaboradorSelecionado.jornadaPrevista.entrada} - {colaboradorSelecionado.jornadaPrevista.saidaExpediente}
                  </span>
                </div>
              </div>

              {/* Tabela Resumida da Jornada Prevista & Batidas de Hoje */}
              <div className="grid grid-cols-4 gap-2 pt-3 text-center">
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/80">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase">1. Entrada</span>
                  <span className="font-mono text-xs font-bold text-slate-800">
                    {colaboradorSelecionado.jornadaPrevista.entrada}
                  </span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/80">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase">2. Saída Int.</span>
                  <span className="font-mono text-xs font-bold text-slate-800">
                    {colaboradorSelecionado.jornadaPrevista.saidaIntervalo}
                  </span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/80">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase">3. Ret. Int.</span>
                  <span className="font-mono text-xs font-bold text-slate-800">
                    {colaboradorSelecionado.jornadaPrevista.retornoIntervalo}
                  </span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/80">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase">4. Saída Exp.</span>
                  <span className="font-mono text-xs font-bold text-slate-800">
                    {colaboradorSelecionado.jornadaPrevista.saidaExpediente}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-500">
              <User className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-semibold">Nenhum colaborador selecionado.</p>
            </div>
          )}

          {/* RF-01: Os 4 Eventos Oficiais de Registro de Ponto (Touch Grande para Tablet) */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 tracking-tight">
                  RF-01: Registro de Ponto (Selecione o Evento)
                </h4>
                <p className="text-xs text-slate-500">
                  Tempo de resposta sub-segundo com carimbo UTC e assinatura digital SHA-256
                </p>
              </div>
              <span className="text-[11px] font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                Tolerância CLT: 5min / máx 10min
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              
              {/* Evento 1: Entrada */}
              <button
                type="button"
                onClick={() => handleBaterPonto('ENTRADA')}
                disabled={processandoRegistro}
                className="group relative flex items-center justify-between p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-emerald-500 hover:bg-emerald-50/40 active:bg-emerald-100 transition shadow-xs text-left"
              >
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded">
                    Evento 1
                  </span>
                  <div className="text-base font-bold text-slate-900 mt-1">
                    Entrada no Expediente
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Início da jornada de trabalho
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition">
                  <Clock className="w-5 h-5" />
                </div>
              </button>

              {/* Evento 2: Saída para Intervalo */}
              <button
                type="button"
                onClick={() => handleBaterPonto('SAIDA_INTERVALO')}
                disabled={processandoRegistro}
                className="group relative flex items-center justify-between p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-amber-500 hover:bg-amber-50/40 active:bg-amber-100 transition shadow-xs text-left"
              >
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded">
                    Evento 2
                  </span>
                  <div className="text-base font-bold text-slate-900 mt-1">
                    Saída p/ Intervalo
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Início do intervalo intrajornada
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center group-hover:scale-110 transition">
                  <Clock className="w-5 h-5" />
                </div>
              </button>

              {/* Evento 3: Retorno do Intervalo */}
              <button
                type="button"
                onClick={() => handleBaterPonto('RETORNO_INTERVALO')}
                disabled={processandoRegistro}
                className="group relative flex items-center justify-between p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-sky-500 hover:bg-sky-50/40 active:bg-sky-100 transition shadow-xs text-left"
              >
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-sky-700 bg-sky-100/80 px-2 py-0.5 rounded">
                    Evento 3
                  </span>
                  <div className="text-base font-bold text-slate-900 mt-1">
                    Retorno do Intervalo
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Reinício do expediente
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center group-hover:scale-110 transition">
                  <Clock className="w-5 h-5" />
                </div>
              </button>

              {/* Evento 4: Saída do Expediente */}
              <button
                type="button"
                onClick={() => handleBaterPonto('SAIDA_EXPEDIENTE')}
                disabled={processandoRegistro}
                className="group relative flex items-center justify-between p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-indigo-500 hover:bg-indigo-50/40 active:bg-indigo-100 transition shadow-xs text-left"
              >
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-100/80 px-2 py-0.5 rounded">
                    Evento 4
                  </span>
                  <div className="text-base font-bold text-slate-900 mt-1">
                    Saída do Expediente
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Término da jornada de trabalho
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center group-hover:scale-110 transition">
                  <Clock className="w-5 h-5" />
                </div>
              </button>

            </div>
          </div>

          {/* Histórico das Marcações de Hoje do Colaborador */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Marcações Registradas Hoje ({new Date().toLocaleDateString('pt-BR')})
              </h4>
              <span className="text-xs font-semibold text-slate-500">
                {registrosHoje.length} evento(s)
              </span>
            </div>

            {registrosHoje.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center italic">
                Nenhum ponto registrado para este colaborador hoje.
              </p>
            ) : (
              <div className="space-y-2">
                {registrosHoje.map((reg) => (
                  <div
                    key={reg.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <div>
                        <span className="font-bold text-slate-900">
                          {reg.tipoEvento.replace('_', ' ')}
                        </span>
                        <span className="text-slate-500 text-[11px] ml-2">
                          às <strong>{reg.horaLocal}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-600">
                        NSR #{reg.nsr}
                      </span>
                      <button
                        type="button"
                        onClick={() => setTicketModalRegistro(reg)}
                        className="text-xs text-blue-700 hover:text-blue-900 font-semibold px-2 py-1 rounded hover:bg-blue-50"
                      >
                        Ver Ticket
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Modal de Justificativa Obrigatória (RF-03) */}
      {justificativaPendente && colaboradorSelecionado && (
        <JustificativaModal
          colaborador={colaboradorSelecionado}
          tipoEvento={justificativaPendente.evento}
          motivoTolerancia={justificativaPendente.motivoTolerancia}
          minutosVariacao={justificativaPendente.minutosVariacao}
          onConfirmar={handleConfirmarJustificativa}
          onCancelar={() => setJustificativaPendente(null)}
        />
      )}

      {/* Modal de Emissão do Ticket Térmico / Digital (RF-02 / RF-09) */}
      {ticketModalRegistro && (
        <TicketTermicoModal
          registro={ticketModalRegistro}
          empresa={empresa}
          impressoraStatus={hardware.impressoraStatus}
          onClose={() => setTicketModalRegistro(null)}
        />
      )}

    </div>
  );
};
