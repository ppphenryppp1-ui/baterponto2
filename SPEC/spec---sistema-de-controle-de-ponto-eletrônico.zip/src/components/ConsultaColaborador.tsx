import React, { useState, useEffect } from 'react';
import {
  Search,
  User,
  Clock,
  Printer,
  Mail,
  Calendar,
  CheckCircle2,
  FileText,
  ShieldCheck,
} from 'lucide-react';
import { Colaborador, EmpresaConfig, HardwareState, RegistroPonto } from '../types';
import { dbService } from '../services/db';
import { TicketTermicoModal } from './TicketTermicoModal';

interface ConsultaColaboradorProps {
  empresa: EmpresaConfig;
  hardware: HardwareState;
}

export const ConsultaColaborador: React.FC<ConsultaColaboradorProps> = ({ empresa, hardware }) => {
  const [colaboradores, setColaboradores] = useState<Colaborador[]>([]);
  const [colaboradorSelecionado, setColaboradorSelecionado] = useState<Colaborador | null>(null);
  const [dataSelecionada, setDataSelecionada] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [registros, setRegistros] = useState<RegistroPonto[]>([]);
  const [registroModal, setRegistroModal] = useState<RegistroPonto | null>(null);

  useEffect(() => {
    dbService.getColaboradores().then((list) => {
      setColaboradores(list);
      if (list.length > 0) {
        setColaboradorSelecionado(list[0]);
      }
    });
  }, []);

  useEffect(() => {
    if (colaboradorSelecionado) {
      dbService.getRegistros().then((regs) => {
        const filtrados = regs.filter(
          (r) =>
            r.colaboradorId === colaboradorSelecionado.id &&
            (!dataSelecionada || r.dataIso === dataSelecionada)
        );
        setRegistros(filtrados);
      });
    }
  }, [colaboradorSelecionado, dataSelecionada]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Cabeçalho de Consulta */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Consulta e Emissão de Comprovantes do Trabalhador
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Acesso transparente aos comprovantes fiscais conforme Portaria MTE 671/2021
          </p>
        </div>

        {/* Seleção do Trabalhador & Data */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-slate-400" />
            <select
              value={colaboradorSelecionado?.id || ''}
              onChange={(e) => {
                const colab = colaboradores.find((c) => c.id === e.target.value);
                if (colab) setColaboradorSelecionado(colab);
              }}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-900 outline-none"
            >
              {colaboradores.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome} ({c.cargo})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input
              type="date"
              value={dataSelecionada}
              onChange={(e) => setDataSelecionada(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-900 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Detalhes do Trabalhador */}
      {colaboradorSelecionado && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-base">
              {colaboradorSelecionado.nome.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{colaboradorSelecionado.nome}</h3>
              <p className="text-xs text-slate-500">
                PIS/PASEP: <strong>{colaboradorSelecionado.pis}</strong> • CPF: <strong>{colaboradorSelecionado.cpf}</strong>
              </p>
              <p className="text-xs text-slate-500">
                Turno Oficial: {colaboradorSelecionado.turnoDescricao}
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 block">E-mail Cadastrado para Tickets (RF-09):</span>
            <span className="text-xs font-semibold text-blue-700">{colaboradorSelecionado.email}</span>
          </div>
        </div>
      )}

      {/* Lista de Marcações com Acesso ao Ticket */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between text-xs">
          <h4 className="font-bold text-slate-900 uppercase tracking-wider">
            Marcações Registradas na Data ({registros.length})
          </h4>
          <span className="text-slate-500">Clique para emitir ou reenviar comprovante</span>
        </div>

        {registros.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            Nenhum registro de ponto encontrado para este colaborador na data selecionada.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {registros.map((reg) => (
              <div
                key={reg.id}
                className="p-4 hover:bg-slate-50 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-mono font-bold">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">
                        {reg.tipoEvento.replace('_', ' ')}
                      </span>
                      <span className="font-mono font-semibold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                        {reg.horaLocal}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        NSR #{String(reg.nsr).padStart(9, '0')}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Autenticação: {reg.metodoAutenticacao} • Carimbo UTC: {reg.timestampUtc.substring(11, 19)}
                    </div>
                    {reg.justificativa && (
                      <div className="text-[11px] text-amber-800 mt-1 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 inline-block">
                        Justificativa: {reg.justificativa}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setRegistroModal(reg)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold text-xs shadow-xs transition"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Ver Ticket / Reimprimir</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal de Ticket Térmico / Digital */}
      {registroModal && (
        <TicketTermicoModal
          registro={registroModal}
          empresa={empresa}
          impressoraStatus={hardware.impressoraStatus}
          onClose={() => setRegistroModal(null)}
        />
      )}

    </div>
  );
};
