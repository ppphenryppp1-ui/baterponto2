import React from 'react';
import {
  Wifi,
  WifiOff,
  Printer,
  AlertTriangle,
  CheckCircle2,
  X,
  Camera,
  RefreshCw,
  HardDrive,
  Sliders,
} from 'lucide-react';
import { HardwareState, StatusImpressora } from '../types';

interface HardwareStatusModalProps {
  hardware: HardwareState;
  setHardware: React.Dispatch<React.SetStateAction<HardwareState>>;
  onClose: () => void;
  onSyncOffline: () => void;
  offlineCount: number;
}

export const HardwareStatusModal: React.FC<HardwareStatusModalProps> = ({
  hardware,
  setHardware,
  onClose,
  onSyncOffline,
  offlineCount,
}) => {
  const toggleRede = () => {
    setHardware((prev) => ({
      ...prev,
      redeOnline: !prev.redeOnline,
    }));
  };

  const setImpressora = (status: StatusImpressora) => {
    setHardware((prev) => ({
      ...prev,
      impressoraStatus: status,
      bobinaPorcentagem: status === 'SEM_PAPEL' ? 0 : prev.bobinaPorcentagem === 0 ? 85 : prev.bobinaPorcentagem,
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Cabeçalho */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="text-sm font-bold">Diagnóstico de Hardware & Periféricos (RF-08)</h3>
              <p className="text-[11px] text-slate-300">
                Monitoramento e simulação de sensores de impressora e conectividade de rede
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Sessão 1: Conectividade de Rede (RF-08 & RNF-01) */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                {hardware.redeOnline ? (
                  <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                    <Wifi className="w-5 h-5" />
                  </div>
                ) : (
                  <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                    <WifiOff className="w-5 h-5" />
                  </div>
                )}
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Conectividade com Servidor / Nuvem
                  </h4>
                  <p className="text-xs text-slate-600">
                    Status Atual:{' '}
                    <span className={`font-bold ${hardware.redeOnline ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {hardware.redeOnline ? 'ONLINE (Conectado via TCP/IP)' : 'OFFLINE (Contingência IndexedDB Ativa)'}
                    </span>
                  </p>
                </div>
              </div>

              {/* Botão de Toggle para Teste */}
              <button
                onClick={toggleRede}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition ${
                  hardware.redeOnline
                    ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300'
                    : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border-emerald-300'
                }`}
              >
                {hardware.redeOnline ? 'Simular Queda de Rede' : 'Restabelecer Rede'}
              </button>
            </div>

            {/* Fila de Sincronização Local */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-slate-500" />
                <span>Registros em fila local (IndexedDB): <strong>{offlineCount} pendentes</strong></span>
              </div>
              <button
                onClick={onSyncOffline}
                disabled={!hardware.redeOnline || offlineCount === 0}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-800 disabled:text-slate-400 disabled:cursor-not-allowed"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sincronizar Agora</span>
              </button>
            </div>
          </div>

          {/* Sessão 2: Impressora Térmica Fiscal (RF-02, RF-08, RF-09) */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div
                  className={`p-2 rounded-lg ${
                    hardware.impressoraStatus === 'OPERACIONAL'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-rose-100 text-rose-700'
                  }`}
                >
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Impressora Térmica de Bobina (80mm)
                  </h4>
                  <p className="text-xs text-slate-600">
                    Status Atual:{' '}
                    <span
                      className={`font-bold ${
                        hardware.impressoraStatus === 'OPERACIONAL'
                          ? 'text-emerald-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {hardware.impressoraStatus === 'OPERACIONAL'
                        ? 'OPERACIONAL (Pronta para Ticket)'
                        : hardware.impressoraStatus === 'SEM_PAPEL'
                        ? 'SEM PAPEL / BOBINA ESGOTADA'
                        : 'DEFEITO MECÂNICO / BLOQUEADA'}
                    </span>
                  </p>
                </div>
              </div>

              <span className="text-xs font-mono font-bold bg-white px-2.5 py-1 rounded border border-slate-300 text-slate-800">
                Bobina: {hardware.bobinaPorcentagem}%
              </span>
            </div>

            {/* Simulador de Estados da Impressora */}
            <div className="space-y-1.5 pt-1">
              <label className="text-[11px] font-bold text-slate-500 uppercase">
                Simular Condição de Hardware:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setImpressora('OPERACIONAL')}
                  className={`py-2 px-2 text-xs font-semibold rounded-lg border transition ${
                    hardware.impressoraStatus === 'OPERACIONAL'
                      ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                  }`}
                >
                  Operacional
                </button>
                <button
                  type="button"
                  onClick={() => setImpressora('SEM_PAPEL')}
                  className={`py-2 px-2 text-xs font-semibold rounded-lg border transition ${
                    hardware.impressoraStatus === 'SEM_PAPEL'
                      ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                  }`}
                >
                  Sem Papel (RF-08)
                </button>
                <button
                  type="button"
                  onClick={() => setImpressora('DEFEITO')}
                  className={`py-2 px-2 text-xs font-semibold rounded-lg border transition ${
                    hardware.impressoraStatus === 'DEFEITO'
                      ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                  }`}
                >
                  Defeito Mecânico
                </button>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 italic">
              * Quando a impressora estiver em falta de papel ou com defeito, o sistema aciona o alerta visual (RF-08) e direciona automaticamente o ticket para o e-mail do colaborador (RF-09).
            </p>
          </div>

          {/* Sessão 3: Câmera Nativa (RF-05) */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-sky-100 text-sky-700 rounded-lg">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Câmera de Biometria Facial (`getUserMedia`)
                </h4>
                <p className="text-xs text-slate-600">
                  Pronta para captura de foto instantânea no momento da marcação.
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded">
              Disponível
            </span>
          </div>

        </div>

        {/* Rodapé */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition"
          >
            Fechar Diagnóstico
          </button>
        </div>

      </div>
    </div>
  );
};
