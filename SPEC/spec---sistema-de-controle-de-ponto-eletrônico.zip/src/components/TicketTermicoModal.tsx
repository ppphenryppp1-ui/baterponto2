import React, { useState } from 'react';
import {
  Printer,
  Mail,
  CheckCircle2,
  X,
  ShieldCheck,
  AlertTriangle,
  Download,
  Copy,
} from 'lucide-react';
import { EmpresaConfig, RegistroPonto, StatusImpressora } from '../types';

interface TicketTermicoModalProps {
  registro: RegistroPonto;
  empresa: EmpresaConfig;
  impressoraStatus: StatusImpressora;
  onClose: () => void;
  onEmailSent?: (email: string) => void;
}

export const TicketTermicoModal: React.FC<TicketTermicoModalProps> = ({
  registro,
  empresa,
  impressoraStatus,
  onClose,
  onEmailSent,
}) => {
  const [emailStatus, setEmailStatus] = useState<'IDLE' | 'SENDING' | 'SENT'>('IDLE');
  const [impressoStatus, setImpressoStatus] = useState<boolean>(
    impressoraStatus === 'OPERACIONAL'
  );
  const [copiado, setCopiado] = useState(false);

  const formatarEventoNome = (tipo: string) => {
    switch (tipo) {
      case 'ENTRADA':
        return '1 - ENTRADA NO EXPEDIENTE';
      case 'SAIDA_INTERVALO':
        return '2 - SAÍDA PARA INTERVALO';
      case 'RETORNO_INTERVALO':
        return '3 - RETORNO DO INTERVALO';
      case 'SAIDA_EXPEDIENTE':
        return '4 - SAÍDA DO EXPEDIENTE';
      default:
        return tipo;
    }
  };

  const handlePrint = () => {
    if (impressoraStatus !== 'OPERACIONAL') {
      alert('Aviso de Hardware: A impressora física está sem papel ou indisponível. Utilize o envio digital por e-mail.');
      return;
    }
    window.print();
    setImpressoStatus(true);
  };

  const handleSendEmail = () => {
    setEmailStatus('SENDING');
    setTimeout(() => {
      setEmailStatus('SENT');
      if (onEmailSent) {
        onEmailSent(registro.emailEnviadoPara || 'colaborador@techsolutions.com.br');
      }
    }, 600);
  };

  const handleCopyHash = () => {
    navigator.clipboard.writeText(registro.hashSha256);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        
        {/* Cabeçalho do Modal */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-sm font-bold tracking-tight">Comprovante de Registro de Ponto</h3>
              <p className="text-[11px] text-slate-300 font-mono">NSR #{String(registro.nsr).padStart(9, '0')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alerta de Hardware da Impressora se houver falha */}
        {impressoraStatus !== 'OPERACIONAL' && (
          <div className="bg-rose-50 border-b border-rose-200 px-6 py-3 flex items-center gap-3 text-rose-800 text-xs">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <div className="flex-1">
              <strong>RF-08 / RF-09 - Impressora Indisponível ({impressoraStatus === 'SEM_PAPEL' ? 'Sem Papel' : 'Defeito Mecânico'}):</strong>
              <p className="mt-0.5">O comprovante digital foi automaticamente direcionado para o e-mail cadastrado.</p>
            </div>
          </div>
        )}

        {/* Área do Ticket Térmico Estilizado (Visual Fiel à Bobina 80mm) */}
        <div className="p-6 bg-slate-100 flex justify-center">
          <div
            id="ticket-termico-print"
            className="w-full max-w-sm bg-white p-6 rounded shadow-md border-t-8 border-slate-700 font-mono text-xs text-slate-900 relative"
            style={{ fontFamily: 'Courier New, monospace, monospace' }}
          >
            {/* Efeito picotado de guilhotina na parte superior */}
            <div className="border-b-2 border-dashed border-slate-400 pb-3 text-center">
              <div className="text-[11px] font-bold uppercase tracking-wider">
                COMPROVANTE DE REGISTRO DE PONTO DO TRABALHADOR
              </div>
              <div className="text-[10px] text-slate-600 mt-1">
                Portaria MTE nº 671/2021 - REP-P
              </div>
            </div>

            {/* Dados do Empregador */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-0.5 text-[11px]">
              <div className="font-bold uppercase text-slate-950">{empresa.razaoSocial}</div>
              <div><strong>CNPJ:</strong> {empresa.cnpj}</div>
              <div className="text-[10px] text-slate-700 leading-tight">
                <strong>Local:</strong> {empresa.endereco}
              </div>
              <div className="text-[10px] text-slate-600">
                <strong>Equipamento:</strong> {empresa.numeroEquipamento}
              </div>
            </div>

            {/* Dados do Trabalhador */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 text-[11px]">
              <div><strong>NOME:</strong> {registro.colaboradorNome}</div>
              <div><strong>PIS/PASEP:</strong> {registro.pis}</div>
              <div><strong>CPF:</strong> {registro.cpf}</div>
              <div><strong>CARGO:</strong> {registro.cargo}</div>
            </div>

            {/* Dados da Marcação */}
            <div className="py-3 border-b-2 border-dashed border-slate-400 space-y-1.5 bg-slate-50/70 p-2 my-1 rounded">
              <div className="text-center font-bold text-xs uppercase bg-slate-900 text-white py-1 rounded">
                {formatarEventoNome(registro.tipoEvento)}
              </div>
              <div className="flex justify-between items-center pt-1 text-xs">
                <span>DATA / HORA LOCAL:</span>
                <span className="font-bold text-slate-950">{registro.horaLocal}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] text-slate-600">
                <span>DATA CALENDÁRIO:</span>
                <span className="font-semibold">{registro.dataIso.split('-').reverse().join('/')}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] text-slate-600">
                <span>HORÁRIO UTC OFICIAL:</span>
                <span className="font-semibold">{registro.timestampUtc.substring(11, 19)} UTC</span>
              </div>
              <div className="flex justify-between items-center text-[10px] text-slate-600">
                <span>MÉTODO:</span>
                <span className="font-semibold">{registro.metodoAutenticacao}</span>
              </div>
              {registro.justificativa && (
                <div className="text-[10px] text-amber-900 bg-amber-50 p-1.5 rounded border border-amber-200 mt-1">
                  <strong>Justificativa gravada:</strong> {registro.justificativa}
                </div>
              )}
            </div>

            {/* NSR e Chave Criptográfica */}
            <div className="pt-2 pb-1 space-y-1 text-[10px] text-slate-700">
              <div className="flex justify-between font-bold">
                <span>NSR:</span>
                <span>{String(registro.nsr).padStart(9, '0')}</span>
              </div>
              <div>
                <span className="block font-semibold">ASSINATURA DIGITAL (SHA-256):</span>
                <span className="block break-all font-mono text-[9px] bg-slate-100 p-1 rounded border border-slate-200">
                  {registro.hashSha256}
                </span>
              </div>
            </div>

            {/* Rodapé Fiscal */}
            <div className="border-t border-dashed border-slate-300 pt-2 text-center text-[9px] text-slate-500">
              DOCUMENTO VÁLIDO PARA FINS TRABALHISTAS<br />
              CONSERVE ESTE COMPROVANTE
            </div>
          </div>
        </div>

        {/* Rodapé com Ações de Emissão */}
        <div className="p-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          
          <button
            onClick={handleCopyHash}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copiado ? 'Hash Copiado!' : 'Copiar Hash SHA-256'}</span>
          </button>

          <div className="flex items-center gap-2">
            {/* Botão de Envio Digital por Email (RF-09) */}
            <button
              onClick={handleSendEmail}
              disabled={emailStatus === 'SENDING' || emailStatus === 'SENT'}
              className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition ${
                emailStatus === 'SENT'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>
                {emailStatus === 'SENDING'
                  ? 'Enviando...'
                  : emailStatus === 'SENT'
                  ? 'Enviado por E-mail'
                  : 'Enviar por E-mail (RF-09)'}
              </span>
            </button>

            {/* Botão de Impressão Física (RF-02) */}
            <button
              onClick={handlePrint}
              className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg text-white shadow-xs transition ${
                impressoraStatus === 'OPERACIONAL'
                  ? 'bg-blue-700 hover:bg-blue-800'
                  : 'bg-slate-400 cursor-not-allowed'
              }`}
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir Ticket (RF-02)</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-300 transition"
            >
              Concluir
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
