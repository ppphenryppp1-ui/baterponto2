import React, { useState, useEffect } from 'react';
import { Tablet, Monitor, AlertTriangle } from 'lucide-react';

export const ScreenNotice: React.FC = () => {
  const [isTooNarrow, setIsTooNarrow] = useState(false);

  useEffect(() => {
    const checkWidth = () => {
      setIsTooNarrow(window.innerWidth < 768);
    };

    checkWidth();
    window.addEventListener('resize', checkWidth);
    return () => window.removeEventListener('resize', checkWidth);
  }, []);

  if (!isTooNarrow) return null;

  return (
    <div className="bg-amber-500 text-slate-950 px-4 py-2 text-xs font-medium flex items-center justify-between shadow-xs z-50">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-slate-950 shrink-0" />
        <span>
          <strong>Aviso de Compatibilidade:</strong> Este sistema foi projetado exclusivamente para <strong>Tablets e Desktops (largura mínima de 768px)</strong>. Gire o tablet para modo paisagem ou amplie a janela para melhor operação.
        </span>
      </div>
      <div className="flex items-center gap-2 ml-4 shrink-0 text-slate-900">
        <Tablet className="w-4 h-4" />
        <Monitor className="w-4 h-4" />
      </div>
    </div>
  );
};
