import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Printer,
  AlertCircle,
  Clock,
  ShieldCheck,
  Building2,
  SlidersHorizontal,
} from 'lucide-react';
import { HardwareState } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  hardware: HardwareState;
  onOpenHardwareModal: () => void;
  activeTab: 'kiosk' | 'consult' | 'gestor';
  setActiveTab: (tab: 'kiosk' | 'consult' | 'gestor') => void;
  inconsistenciasNaoResolvidasCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  hardware,
  onOpenHardwareModal,
  activeTab,
  setActiveTab,
  inconsistenciasNaoResolvidasCount,
}) => {
  const [currentDateTime, setCurrentDateTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const horaFormatada = currentDateTime.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const dataFormatada = currentDateTime.toLocaleDateString('pt-BR', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Logo e Identificação do REP */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center text-white shadow-xs">
              <ShieldCheck className="w-6 h-6 text-sky-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-slate-900 tracking-tight">
                  TECHSOLUTIONS
                </span>
                <span className="text-[11px] font-semibold uppercase tracking-wider bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                  REP-P 671/2021
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Terminal de Registro Eletrônico de Ponto
              </p>
            </div>
          </div>

          {/* Navegação Principal */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/80 p-1 rounded-xl border border-slate-200/80">
            <button
              onClick={() => setActiveTab('kiosk')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'kiosk'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              Terminal Quiosque
            </button>
            <button
              onClick={() => setActiveTab('consult')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'consult'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              Consulta do Trabalhador
            </button>
            <button
              onClick={() => setActiveTab('gestor')}
              className={`relative px-4 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-2 ${
                activeTab === 'gestor'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <span>Painel do Gestor / RH</span>
              {inconsistenciasNaoResolvidasCount > 0 && (
                <span className="inline-flex items-center justify-center bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-4.5">
                  {inconsistenciasNaoResolvidasCount}
                </span>
              )}
            </button>
          </nav>

          {/* Componentes de Status Fixo & Relógio */}
          <div className="flex items-center gap-3">
            
            {/* Relógio Digital Oficial */}
            <div className="text-right hidden sm:block pr-3 border-r border-slate-200">
              <div className="text-lg font-mono font-bold text-slate-900 tracking-tight leading-none">
                {horaFormatada}
              </div>
              <div className="text-[11px] font-medium text-slate-500 uppercase mt-0.5">
                {dataFormatada} • BRT
              </div>
            </div>

            {/* Status Fixo da Rede */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition ${
                hardware.redeOnline
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
              }`}
              onClick={onOpenHardwareModal}
              title="Clique para diagnosticar conectividade de rede"
            >
              {hardware.redeOnline ? (
                <>
                  <Wifi className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 text-amber-600 animate-pulse" />
                  <span className="font-semibold">Offline</span>
                </>
              )}
            </div>

            {/* Status Fixo da Impressora */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition ${
                hardware.impressoraStatus === 'OPERACIONAL'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'
              }`}
              onClick={onOpenHardwareModal}
              title="Clique para configurar e testar impressora térmica"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span className="font-semibold">
                {hardware.impressoraStatus === 'OPERACIONAL'
                  ? 'Impressora OK'
                  : hardware.impressoraStatus === 'SEM_PAPEL'
                  ? 'Sem Papel'
                  : 'Defeito Impressora'}
              </span>
            </div>

            {/* Botão de Hardware Diagnostics */}
            <button
              onClick={onOpenHardwareModal}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
              title="Diagnóstico de Hardware & Periféricos"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>

            {/* PWA Install */}
            <PWAInstallButton />
          </div>

        </div>

        {/* Mobile / Tablet sub-navigation bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-100">
          <button
            onClick={() => setActiveTab('kiosk')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md ${
              activeTab === 'kiosk' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Quiosque
          </button>
          <button
            onClick={() => setActiveTab('consult')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md ${
              activeTab === 'consult' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Consulta
          </button>
          <button
            onClick={() => setActiveTab('gestor')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md relative ${
              activeTab === 'gestor' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Gestor / RH
            {inconsistenciasNaoResolvidasCount > 0 && (
              <span className="ml-1.5 inline-block w-2 h-2 rounded-full bg-red-500" />
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
