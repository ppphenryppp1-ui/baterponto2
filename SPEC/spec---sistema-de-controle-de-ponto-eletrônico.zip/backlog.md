# Backlog do Projeto - Sistema de Controle de Ponto Eletrônico (PWA REP-P)

Documento obrigatório de rastreabilidade de funcionalidades, status e escopo conforme especificação do projeto.

---

## Registros de Versão e Funcionalidades

| Data | ID | Funcionalidade / Tarefa | Escopo / Descrição Detalhada | Status |
| :--- | :--- | :--- | :--- | :--- |
| 2026-09-24 | **SETUP-01** | Infraestrutura PWA & Assets | Configuração de `vite-plugin-pwa`, Service Worker com autoUpdate, Web App Manifest com safe zones, ícones 192px/512px/maskable/apple-touch e layout otimizado para tablets/desktops (min-width: 768px). | Concluído |
| 2026-09-24 | **RF-01** | Registro de Ponto em 4 Eventos | Interface de toque com 4 eventos legais: Entrada no Expediente, Saída para Intervalo, Retorno do Intervalo e Saída do Expediente. | Concluído |
| 2026-09-24 | **RF-02** | Emissão de Comprovante Térmico | Emissão de ticket conforme Portaria MTE 671 contendo Razão Social, CNPJ, Endereço, Nome, PIS, CPF, Cargo, Turno, Horário Exato, NSR e assinatura SHA-256 com `@media print` para impressoras 80mm. | Concluído |
| 2026-09-24 | **RF-03** | Registro Obrigatório de Justificativa | Detecção de extrapolação da tolerância (5 min na batida ou 10 min diários acumulados) e abertura de modal obrigatório com seleção de motivos padronizados e texto livre antes de gravar. | Concluído |
| 2026-09-24 | **RF-04** | Notificação de Inconsistências | Painel do Gestor/RH com monitoramento em tempo real de atrasos, saídas antecipadas, faltas e justificativas pendentes, com fluxo de homologação e parecer do RH. | Concluído |
| 2026-09-24 | **RF-05** | Autenticação Biométrica / Foto Câmera | Captura de foto ao vivo via `navigator.mediaDevices.getUserMedia` com enquadramento guia oval e gravação de snapshot base64 auditável. | Concluído |
| 2026-09-24 | **RF-06** | Autenticação de Exceção (RFID & PIN) | Teclado numérico touch virtual para PIN e leitor de aproximação RFID / Código de Crachá com validação em base de dados local. | Concluído |
| 2026-09-24 | **RF-07** | Gestão de Atestados e Abonos Médicos | Módulo de RH para submissão, conferência e aprovação de atestados médicos com CID, CRM do médico e período de abono automático de faltas. | Concluído |
| 2026-09-24 | **RF-08** | Alertas Visuais de Hardware | Indicadores fixos visuais de status da Rede (Online/Offline) e Impressora (Operacional/Sem Papel/Defeito), modal de diagnóstico com simulação de bobina e corte de papel. | Concluído |
| 2026-09-24 | **RF-09** | Comprovante Digital por E-mail | Transmissão automática do comprovante digital para o e-mail cadastrado em caso de falta de papel/defeito na impressora ou reemissão pelo trabalhador. | Concluído |
| 2026-09-24 | **RN-01** | Regra de Tolerância de 5/10 min | Validação automática de tolerância de 5 min por marcação individual e limite máximo de 10 min acumulados no dia (CLT Art. 58 § 1º). | Concluído |
| 2026-09-24 | **RN-02** | Cálculo de Descontos e Horas Excedentes | Apuração automática dos minutos divergentes para subsidiar descontos em folha ou crédito no banco de horas. | Concluído |
| 2026-09-24 | **RN-03** | Imutabilidade e Carimbo Criptográfico | Assinatura digital SHA-256 gerada com carimbo UTC oficial, NSR crescente sequencial e impossibilidade de alteração posterior. | Concluído |
| 2026-09-24 | **RN-04** | Apuração Automática de Faltas | Identificação automática de colaboradores ativos sem marcações ao término do expediente com geração de registro de Falta Injustificada. | Concluído |
| 2026-09-24 | **RNF-01** | Arquitetura Offline-first (IndexedDB) | Persistência local segura em IndexedDB (`REP_P_DATABASE_v1`) com fila de contingência e sincronização automática transparente ao restabelecer a conexão. | Concluído |
| 2026-09-24 | **RNF-02** | Desempenho Local Sub-segundo | Confirmação e captura instantânea em menos de 1 segundo com feedback visual de alta legibilidade e bip acústico gerado via Web Audio API. | Concluído |
| 2026-09-24 | **RNF-03** | Interface Exclusiva Tablet & Desktop | Clean UI com fundo neutro `#ffffff` / `#f8f9fa`, tipografia moderna sem serifa, alto contraste, sem nenhum emoji, utilizando exclusivamente ícones vetoriais Lucide. | Concluído |
